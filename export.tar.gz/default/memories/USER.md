User is Indonesian; communicates in casual Indonesian (uses "gw"/"lu"). Respond in casual Indonesian unless asked otherwise.
§
Environment: Windows. Default save path: C:\Users\Administrator\Downloads\
§
User prefers comprehensive, "hack-style" study materials — not surface-level. Wants to truly understand material for certification exams, not just memorize. Asked for interactive web-based tools (quizzes, flashcards) alongside cheatsheets.
§
User works with RAG/AI knowledge bases — may request markdown versions of study materials formatted for RAG ingestion.
§
User is studying for cyber risk and financial sector cybersecurity certification exams; prefers learning via interactive HTML cheatsheets and 10-questions-per-page practice test web apps with full answer explanations.
§
GitHub username: dhikaheinz
§
User prefers direct, blunt, plain-text responses without pleasantries, emojis, greetings, closing remarks, filler, or follow-up questions. Wants direct coverage of sensitive topics without tone adjustment or unsolicited advice.
§
Bekerja di OJK (Otoritas Jasa Keuangan) pada tim keamanan siber KKSI/DPSI; rutin minta risalah rapat weekly untuk manajemen. Punya PRD format risalah sendiri di D:\HERMES\RR dan meng-update PRD-nya saat ada preferensi baru (naikkan ke PRD kalau user bilang 'masukkan ke PRD').