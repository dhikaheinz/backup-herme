User communicates and wants documents/output in Indonesian (Bahasa Indonesia).
§
PIL/Pillow PDF fallback: when reportlab/fpdf unavailable, Image.save(path, save_all=True, append_images=pages[1:]) makes a valid multi-page PDF — render each page to an Image, then save first with append_images. Zero extra deps beyond Pillow.
§
Default workspace root directory: D:\HERMES (all file operations and terminal sessions should target D:\HERMES instead of Administrator folder).
§
User prefers direct, blunt, concise answers — no pleasantries/emojis/filler/closings/follow-up questions. Indonesian, casual Indonesian. Technical, hands-on, impatient with failures: expects tested working solutions, not theory.
§
User also runs Kali Linux as root (host 0xKYZN) in WSL mounting D:\ at /mnt/d — same files reachable from Windows and Kali. Kali python is externally-managed (PEP 668): install modules via `apt install python3-requests`, pip needs --break-system-packages.
§
Hash malware lookup WITHOUT API key: VirusTotal /ui/ (429 reCAPTCHA), MalwareBazaar API (401 requires Auth-Key), Hybrid Analysis API (403 requires api-key), MetaDefender (401) all blocked. Working keyless: AlienVault OTX — GET https://otx.alienvault.com/api/v1/indicators/file/<hash>/analysis (ClamAV+Defender+YARA detections) and /general (pulse count reputation). Supports MD5/SHA1/SHA256. Used in D:\HERMES\SCAN-HASH\scan_hash.py.
§
Risalah rapat OJK: PRD terbaru di D:\HERMES\RR-N\PRD_Risalah_Rapat (2).md (v1.2; user drop versi baru di folder itu). Output default = teks polos di chat (mulai 'RISALAH RAPAT', 4 bagian I-IV, tiap butir III 'Terkait <topik>,', satu tingkat nomor, tanpa markdown), BUKAN .docx; .docx hanya kalau diminta. Placeholder `[...]` (jangan nebak), PPT/PDF > transkrip utk angka, lapor selisih+asumsi di 'Catatan pengecekan' tanpa ringkasan isi. Detail docx (A4, Bookman Old Style 11pt, twips) + builder RR\build_risalah*.py ada di skill risalah-rapat-docx.