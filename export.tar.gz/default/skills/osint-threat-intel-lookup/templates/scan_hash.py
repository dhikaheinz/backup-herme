# Known-good OTX hash scanner (tested end-to-end). Copy into the target folder and adapt.
# Auto check hash (MD5 / SHA1 / SHA256) -> GreenFlag / YellowFlag / RedFlag
# Source: AlienVault OTX public API (NO API KEY). AV engines + pulse reputation.
#
# Pakai:
#   python scan_hash.py hashes.txt
#   python scan_hash.py                 (nanti diminta nama file)
#
# Input : file .txt, 1 hash per baris (baris boleh ada spasi/komentar setelah hash)
# Output: tampil di layar (berwarna) + simpan ke results_<nama_file>

import sys
import os
import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://otx.alienvault.com/api/v1/indicators/file/{}"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Accept": "application/json",
}
WORKERS = 5
TIMEOUT = 30

GREEN, YELLOW, RED, RESET = "\033[92m", "\033[93m", "\033[91m", "\033[0m"


def hash_type(h):
    return {32: "MD5", 40: "SHA1", 64: "SHA256"}.get(len(h))


def _av_detections(analysis):
    """Kumpulkan deteksi dari plugin AV (clamav, msdefender) + YARA."""
    dets = []
    for name, plug in (analysis.get("plugins") or {}).items():
        res = plug.get("results") or plug.get("result") or {}
        if not isinstance(res, dict):
            continue
        det = res.get("detection")
        if not det:
            continue
        if isinstance(det, str):
            dets.append(det)
        elif isinstance(det, list):
            for x in det:
                if isinstance(x, dict) and x.get("rule_name"):
                    dets.append(x["rule_name"])
    return dets


def check(h):
    """Return (flag, info). flag = GreenFlag | YellowFlag | RedFlag."""
    try:
        ra = requests.get(BASE.format(h) + "/analysis", headers=HEADERS, timeout=TIMEOUT)
        rg = requests.get(BASE.format(h) + "/general", headers=HEADERS, timeout=TIMEOUT)
    except Exception as e:
        return "YellowFlag", f"network error: {e}"

    analysis = (ra.json().get("analysis") or {}) if ra.status_code == 200 else {}
    general = rg.json() if rg.status_code == 200 else {}

    dets = _av_detections(analysis)
    pulses = (general.get("pulse_info") or {}).get("count", 0)
    validations = general.get("validation") or []
    vnames = [v.get("name") for v in validations if isinstance(v, dict)]
    is_empty = any("empty" in (n or "").lower() for n in vnames)
    is_whitelist = any("whitelist" in (n or "").lower() for n in vnames)

    if dets:
        return "RedFlag", f"AV: {'; '.join(dets[:3])} | pulses={pulses}"
    if is_whitelist or is_empty:
        return "GreenFlag", f"whitelisted/empty file | pulses={pulses}"
    if pulses >= 10:
        return "YellowFlag", f"dilaporkan di {pulses} pulse OTX (mencurigakan)"
    return "GreenFlag", f"tidak ada deteksi | pulses={pulses}"


def load_hashes(path):
    out = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            tok = line.strip().split()[0] if line.strip() else ""
            tok = tok.lower()
            if tok and hash_type(tok):
                out.append(tok)
    # dedupe, jaga urutan
    seen = set()
    return [h for h in out if not (h in seen or seen.add(h))]


def main():
    folder = os.path.dirname(os.path.abspath(__file__))
    arg = sys.argv[1] if len(sys.argv) > 1 else input("Nama file txt berisi hash (mis. hashes.txt): ").strip()
    path = arg if os.path.isabs(arg) else os.path.join(folder, arg)
    if not os.path.isfile(path):
        print(f"File tidak ditemukan: {path}")
        sys.exit(1)

    hashes = load_hashes(path)
    if not hashes:
        print("Tidak ada hash valid (MD5/SHA1/SHA256) di file.")
        sys.exit(1)

    print(f"Total hash: {len(hashes)} | sumber: AlienVault OTX (tanpa API key)\n")
    results = {}
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futs = {ex.submit(check, h): h for h in hashes}
        done = 0
        for fut in as_completed(futs):
            h = futs[fut]
            results[h] = fut.result()
            done += 1
            print(f"\r  progres: {done}/{len(hashes)}", end="", flush=True)
    print("\r" + " " * 30 + "\r", end="")

    counts = {"GreenFlag": 0, "YellowFlag": 0, "RedFlag": 0}
    out_path = os.path.join(folder, f"results_{os.path.basename(path)}")
    color = {"GreenFlag": GREEN, "YellowFlag": YELLOW, "RedFlag": RED}
    print("Hasil:")
    with open(out_path, "w", encoding="utf-8") as out:
        for h in hashes:
            flag, info = results[h]
            counts[flag] += 1
            line = f"{flag}  {h} [{hash_type(h)}]  ({info})"
            out.write(line + "\n")
            print(f"{color[flag]}{line}{RESET}")

    print(f"\nGreenFlag  : {counts['GreenFlag']}")
    print(f"YellowFlag : {counts['YellowFlag']}")
    print(f"RedFlag    : {counts['RedFlag']}")
    print(f"Tersimpan  : {out_path}")


if __name__ == "__main__":
    main()
