# Probed threat-intel endpoints (no API key)

Probed with single live requests calls: one known-malicious hash + one fabricated control. Re-probe before building on any row — provider gates move. Do not trust a row marked WORKING without a fresh probe if the session is far in the future.

| Source | Endpoint | Status | Note |
|---|---|---|---|
| AlienVault OTX | GET https://otx.alienvault.com/api/v1/indicators/file/<hash>/analysis | 200 JSON | WORKING — primary source |
| AlienVault OTX | GET .../general | 200 JSON | WORKING — pulses + validation |
| Team Cymru MHR | hash.cymru.com port 43 | text | WORKING — secondary; often NO_DATA |
| urlscan.io | GET /api/v1/search/?q=files.hash:"<h>" | 200 JSON | only sees hashes observed in scanned pages, 30-day window |
| VirusTotal | GET /ui/files/<hash> (GUI backend) | 429 RecaptchaRequiredError | cookie+reCAPTCHA wall; requests scraping dead |
| VirusTotal | GET /gui/file/<hash> | 200 but shell only | Next.js shell, no data server-side |
| MalwareBazaar | POST mb-api.abuse.ch/api/v1/ query=get_info | 401 | Auth-Key header now mandatory (empty string still 401) |
| Hybrid Analysis | /api/v2/search/hash, /api/v2/search/hashes | 403 / 404 | api-key mandatory; HTML search page is client-rendered (len identical for benign vs malicious) |
| MetaDefender | GET api.metadefender.com/v4/hash/<h> | 401 | key required |
| Jotti | /search/hash/<h> | 404 | endpoint does not exist |
| ThreatMiner | www.threatminer.org/sample.php | 522 | intermittent Cloudflare origin down |
| abuse.ch browse | GET/POST bazaar.abuse.ch/browse.php?search=<h> | 200 len=2 | POST returns empty body; not usable |

## OTX response schema

`/analysis` →
```json
{"analysis": {"plugins": {
  "clamav":     {"results": {"detection": "<str>", "alerts": ["Malware infection"]}},
  "msdefender": {"results": {"detection": "<str>"}},
  "yarad":      {"results": {"detection": [{"rule_name": "...", "severity": 0}]}}
},
"info": {"results": {"md5": "...", "sha1": "...", "sha256": "...", "filesize": N, "file_type": "..."}}}}
```
- 200 with empty/missing plugins = hash unknown to OTX → no-data (Green with note).
- `detection` is str (clamav/msdefender) OR list of dicts (yarad) — one parser must handle both.
- Any hash type accepted in the URL; info.results cross-links all three hashes.

`/general` → `pulse_info.count` (reputation), `validation` = [{"name": "Empty hash"|"Whitelisted hash", ...}].

## Team Cymru MHR (port 43 whois-style)
```python
import socket
s = socket.create_connection(("hash.cymru.com", 43), timeout=20)
s.sendall(b"begin\n" + "\n".join(md5s).encode() + b"\nend\n")  # begin sha1 / begin sha256 for other types
s.settimeout(15)
try:
    while True:
        c = s.recv(4096)
        if not c: break
        data += c
except socket.timeout:
    pass  # normal EOF for this service
```
Response lines: `<hash> <epoch> NO_DATA` or `<hash> <epoch> <detection_percent>`.

## Test vectors for verdict logic
- EICAR sha256 `275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f` → expect RedFlag (Eicar-Test-Signature; Virus:DOS/EICAR_Test_File)
- EICAR md5 `44d88612fea8a8f36de82e1278abb02f` → expect RedFlag
- sha256("hello") `2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824` → common string hash, many pulses, no AV hit → YellowFlag case
- empty-file sha256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` → whitelisted → GreenFlag
- fabricated hash (`deadbeef0000...`) → no data → GreenFlag
