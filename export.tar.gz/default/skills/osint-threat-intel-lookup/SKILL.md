---
name: osint-threat-intel-lookup
description: Use when checking file hashes or IOCs for malware verdicts.
---

# Threat-Intel Hash/IOC Lookup (no API key)

## Deliverable rules
- "Buat script di folder X" = CREATE the folder and WRITE the script to disk, then RUN it on real data. Never hand back a pasted code block for manual copy-paste — the user iterates on files and judges by executed output, not by reading code in chat.
- Use the EXACT folder path the user names (e.g. D:\HERMES\SCAN-HASH). Verify with `ls` before claiming the folder exists; a same-but-different name (scan_hash vs SCAN-HASH) reads as "folder gada".
- Terse Indonesian output. No emoji bullets (✅⚠🔹), no mock sample output — show what the script actually printed.

## Procedure
1. PROBE ENDPOINTS BEFORE WRITING THE SCANNER. One live request per candidate source (5-line requests test, print status + first 200 chars) with a known-malicious hash and a fabricated control. Many gated APIs return plausible HTML or bare 401/403/429 — a full script built on unprobed endpoints is guaranteed rework. See references/threat-intel-endpoints.md for already-probed status.
2. Write the scanner into the user's folder: auto-detect hash type by length (32=MD5, 40=SHA1, 64=SHA256), lowercase + dedupe preserving order, ThreadPoolExecutor (5 workers), progress counter, colored flag lines, save results_<input>.txt next to input.
3. Validate classification with known vectors before claiming it works (list in references file). Show the real run's flag counts.
4. Report verdict logic in one table: Green = no AV detection + no/whitelisted data; Yellow = suspicious reputation without AV hit; Red = AV detection present.

## Verdict logic (OTX)
- RedFlag: any detection string in analysis plugins (clamav, msdefender, yarad).
- GreenFlag: validation contains "Whitelisted hash"/"Empty hash", or 0 pulses + no detections.
- YellowFlag: ≥10 OTX pulses but no AV detection (community-reported, unconfirmed). Hashes of common strings land here — explain that it is reputation, not proof.
- The detection field may be a str OR a list of {rule_name, severity} — handle both in one parser.

## Pitfalls
- Never build on an endpoint remembered from memory or old snippets. Gated providers: VirusTotal GUI backend (reCAPTCHA wall), MalwareBazaar API (Auth-Key mandatory), Hybrid Analysis API (api-key mandatory), MetaDefender (key). The old BeautifulSoup-scrape-VT-GUI pattern matches no real DOM.
- `requests` is already available in the Hermes python; stdlib+requests only, no new deps.
- When reading a whois-style port-43 service (Team Cymru MHR), socket.timeout on recv is the normal end-of-response, not an error — catch it and parse what arrived.

## Depth
- references/threat-intel-endpoints.md — probed endpoint status table, OTX response schema, MHR port-43 recipe, test vectors
- templates/scan_hash.py — known-good OTX hash scanner, tested end-to-end
