---
name: game-assist
description: Use when driving a game UI to help the user play.
---

# Game Assist

Live session help for games the user is running on this PC. Server (Steam/desktop) titles with custom UI: vision-only, no DOM/SOM elements.

## Workflow

1. **Research the game BEFORE touching the screen.** web_search for tier lists, crafting systems, and item-grade systems. Fresh game data beats guessing from the screen; icons in pixel-art UI are unreadable without knowing the systems.
2. **Find the window:** computer_use list_windows, match the game process name, note pid + window_id. Target all actions there — never full-screen clicks.
3. **Capture with mode='vision'** (SOM returns 0 elements on Unity/game UI — expect it; do not retry SOM). Get a screenshot + vision analysis.
4. **Advise:** read the visible state, identify the problem, give ranked next steps. Answer in casual Indonesian, blunt style (user preference).
5. **Click on the user's confirmation** for any resource-spending or irreversible action.

## Pitfalls (read before acting)

- **Grade/rarity beats item level in idle/gacha RPGs.** Read each item's rarity via icon background/border color (grey common, green uncommon, blue rare, purple epic, orange legendary) before recommending any equipment swap. Recommending a higher-level lower-grade item over a lower-level higher-grade one destroys the player's build — zoom the inventory and grade-read every item first, and state the grade readback to the user before proposing swaps.
- **Zoom before reading.** For low-res pixel UI, re-analyze the cached screenshot with vision_analyze + a tight `region` crop (coords in ORIGINAL image pixels). Icon-level detail (rarity color, +badges, checkmarks, tooltips) is invisible at full-frame scale.
- **Every click is unverifiable.** Follow the capture → click → re-capture loop; verdicts say verify_fresh_state. Never chain two state-changing clicks blind, and never repeat a click just because the verdict told you to verify.
- **Local tools: one call per tool_call.** Batching click+capture in one tool_call is rejected — re-capture in the next call.
- **Do not blind-spend player resources.** Clicks on skill/rune/crafting trees sometimes consume points on mouse-down with no confirm dialog (tooltip may only show on hover). Before clicking any node/slot that could spend currency, points, or materials: describe the target node to the user and get an explicit 'gas' — even if the user asked you to act.
- **Coordinate drift:** UI panels scroll/pan after clicks, so recalibrate coordinates from a fresh capture each time, never reuse coords from an older frame.

## Tooling

- list_windows → pid + window_id → all further calls use pid+window_id.
- capture(mode='vision') for reading; capture(mode='som') only worth one try on apps with real widgets.
- Screenshots are cached under the Hermes images cache (path in tool result) — feed that local path into vision_analyze with region for zoomed re-reads.

## Game data

Per-title data and pitfalls live in `references/<game-slug>.md` (e.g. `references/tbh-task-bar-hero.md`). Add a new one per game rather than expanding this file.
