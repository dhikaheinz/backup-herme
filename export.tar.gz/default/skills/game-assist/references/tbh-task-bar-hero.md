# TBH: Task Bar Hero — quick reference

Data from community wikis (tbhtaskbarhero.com, task-bar-hero.wiki). May shift with patches — re-check before advising.

## Classes
- Free starters: Knight (Sword, tank+S, free best hero), Ranger (Bow, B/overshadowed), Sorcerer (Staff, A/AoE clear).
- Priest: free DLC — claim in store; A-tier support (verify in-game store; marked paid in some listings).
- Paid DLC ~$3: Hunter (S/DLC, best DPS ceiling, crit scaling), Slayer (B/DLC, kill-scaling melee, skippable).
- Party of 3; slots unlocked via Rune Tree with gold.

## Items
- Level ≠ power. Rarity grade decides cube slots: Common 0 / Uncommon 1 / Rare 2 / Legendary 4 / Immortal 5 / Arcana 6 / Beyond+ 7.
- Rarity color on icon bg: grey Common, green Uncommon, blue Rare, purple Epic-tier, orange/gold Legendary+. Red dot = notification, not rarity.
- Cube priority: DPS (Hunter/Slayer) ATK% then CritRate then CritDmg; Knight: Max HP% then Armor then Regen; Priest: Max HP% then HP Regen then DEF%.
- Duplicate affixes do not stack — never cube the same stat twice on one item.

## Rune tree
- White '+' badge = unspent point; green check = owned; dim = locked.
- Node row logic (from walkthroughs): purple line = EXP/utility, gold = gold/economy, blue = HP/sustain, red = damage, shield node = defense.
- Pure-EXP rune builds produce zero combat power and cause stage-fail loops on hard stages.

## Progression logic
- 'Auto-retry on stage failure' toast = stuck loop: retreat 1-2 stages, farm better grade gear, then push.
- Stat cube sockets on gear are the main damage source; unlock via Hero-dric Cube (unlocks Lv4; Decoration Lv8, Engraving Lv15, Inscription Lv25).
