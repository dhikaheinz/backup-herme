---
name: risalah-rapat-docx
description: Use when making formal meeting minutes (risalah rapat).
---

# Risalah Rapat (.docx baku)

Produce formal Indonesian meeting minutes (.docx) per the PRD at `D:\HERMES\RR-N\PRD_Risalah_Rapat (2).md` (v1.2; older `(1).md` under `D:\HERMES\RR\` is superseded) — read it fresh on every request, user drops new versions into `D:\HERMES\RR-N\`. **Since PRD v1.2 the default deliverable is plaintext in the chat, not a file: use this skill ONLY when the user explicitly asks for a `.docx`.** For plaintext risalah load the `risalah-rapat` skill instead. Contoh files at `D:\HERMES\RR\contoh-rr\` are style reference ONLY (gambaran struktur/gaya), never copy verbatim.

## Workflow (per PRD §10)
1. Read transcript + PPT/PDF. Check completeness against PRD §3 field table.
2. Extract facts from PPT/PDF → acuan baku. Jalankan `scripts/extract_pptx_facts.py <file.pptx>` (dump semua slide: text frame, tabel, gambar) — tabel slide adalah sumber angka paling andal (versi/rilis, incident per status, SLA tiket, backup, absensi) dan sering memuat data yang tidak disebut di transkrip. Ambil dari PPT: (a) nama pengadaan/kontrak di tabel slide 3 → dipakai menyusun Agenda, (b) hostname/IP/versi per perangkat, (c) tabel tenaga ahli → nama PT vendor lengkap + jam absensi, (d) slide laporan harian (email weekly) → angka terpisah dari slide health check.
3. Clean transcript per §6A.2/§6A.3 (fix obvious typos; drop filler; map generic "Speaker N" to pihak) then reconcile with step-2 facts.
4. Structure into 4 Roman sections per §5.4 with §6 style.
5. Apply §7 missing-data handling + §6A.4 conflict rules.
6. Build .docx per §5 (recipe: `references/spesifikasi-docx.md`).
7. Render/visual check per §9 before delivery.
8. Deliver file. In chat report ONLY: (a) yellow placeholders left, (b) transcript-vs-PPT discrepancies, (c) other inconsistencies found. NOT a content summary of the document.

## Always-on rules
- Formal-administrative Indonesian (PUEBI): no slang, no direct imperative KKSI directives — pattern "mohon/agar/diharapkan". Max ~25 words/sentence, one idea per bullet.
- No bold anywhere (incl. headings), no emoji, no tables in body sections.
- Never invent facts: missing/ambiguous data → yellow-highlighted `[...]` placeholder + report in chat. Rule: "placeholder kuning yang kelihatan lebih baik daripada angka yang salah tapi rapi".
- Numbers/versions/names: PPT/PDF > transcript. Verbal correction beats slide. Chat metadata beats PPT dates. Report every conflict in chat, never hide.
- Kop: three centered lines, spacing 1.0 — "RISALAH RAPAT", blank, "NOMOR RR-<urutan>/MS.1300/<tahun>" (yellow highlight; empty urutan → "RR-/MS.1300/<tahun>"). Tahun follows meeting year.
- Meta table: 3 cols, no border — rows Hari, Tanggal / Waktu / Tempat / Pemimpin Rapat / Agenda. Tempat & Pemimpin defaults per PRD §5.3/§11 (Tempat: italic + yellow highlight).
- Section III: poin 1 = vendor ("<Singkatan> menyampaikan paparan laporan <periode>"), poin 2 = KKSI ("KKSI menyampaikan hal-hal sebagai berikut:"). If no KKSI content in transcript, DELETE poin 2 — never fill with a generic sentence.
- NON-vendor meetings (koordinasi internal, insiden, kick-off, UAT): the `1./a./i.` hierarchy depends on SPEAKER ROLES, not on whether a vendor attended. If two distinct roles spoke (e.g. satu unit memaparkan hasil, ketua memberi arahan), KEEP the hierarchy and map poin 1 = presenting unit ("<Unit> menyampaikan ... sebagai berikut:"), poin 2 = chair's directives ("<Jabatan> menyampaikan arahan sebagai berikut:"). Only switch to one "Terkait ..." paragraph per item (like the internal-coordination example in contoh-rr, Konsep KKSI) when discussion is undifferentiated with no separate presenter. Always adapt II. TUJUAN to real purpose with "Rapat ini bertujuan untuk ...".
- File name: `RISALAH_RAPAT_<TOPIK_SINGKAT>_<DDMMYY>.docx`; length 1–2 halaman A4.
- TEKNISALITAS default: plain bahasa, on-point — tulis untuk pembaca non-teknis. Untuk temuan keamanan/pentest: simpan severity (tinggi/sedang), dampak dalam bahasa awam, dan satu kalimat "Perlu ..." per temuan. JANGON default ke detail laporan pentest (skor CVSS, CWE/OWASP codes, path endpoint, nama algoritma/fitur perbaikan) kecuali user explicitly minta versi teknis. Kalau user meminta lengkap lalu menyuruh simplifikasi, bangun ulang dari section III poin 1 — tempat meta kop/tabel/struktur tetap, hanya kedalaman isi yang berubah. Simpan varian sebelumnya sebagai `<nama>_detail.docx` sebelum menimpa.

## Toolchain
- python-docx 1.2.0 is importable from the plain `python` on PATH (`python -c "import docx; print(docx.__version__)"` → 1.2.0). Cek itu dulu sebelum mencari venv. Venv alternatif: `C:/Users/Administrator/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe`, dan `pip` absen di sana; install dengan uv:
  `uv pip install --python "C:/Users/Administrator/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe" --index-url https://pypi.tuna.tsinghua.edu.cn/simple <pkg>`
  pypi.org direct is blocked on this network (connection reset); Tsinghua mirror works.
- Render/paginate check: soffice/libreoffice TIDAK terpasang; Microsoft Word COM (pywin32) tersedia — recipe Word COM + page-length control loop ada di `references/spesifikasi-docx.md`.
- Jalankan script build dengan `workdir=D:\HERMES\RR`. Script baru: salin `build_risalah*.py` TERBARU di folder itu sebagai template (nama bisa `build_risalah.py` tanpa sufiks), jangan tulis dari nol — struktur build + verify dipakai ulang. Struktur yang terbukti: konstanta `META/PEMBUKAAN/TUJUAN/HASIL/RTL` di bagian bawah file, `build(out, ...)` di atasnya, `python build_risalah.py <out.docx>`.
- Ubah script build HANYA lewat tool `patch` (find/replace bertarget). JANGAN `write_file` (menolak file yang belum dibaca penuh + menghapus revisi kompresi halaman), dan JANGAN edit lewat skrip Python read-replace (`src.replace(...)` + tulis ulang) — penggantian string yang meleset satu karakter langsung merusak sintaks dan mengubah file sebelum ketahuan. Kalau tetap melakukan banyak penggantian sekaligus, jalankan `python -c "import ast;ast.parse(open('build_risalah.py',encoding='utf-8').read())"` lalu build ulang di perintah yang sama, jangan tunggu sampai delivery.

## Verifikasi struktural (tanpa render)
- Lebar kolom meta table: set `cell.width` saja TIDAK cukup — python-docx menulis `<w:tcW>` tapi grid tetap default (semua kolom 1910715 EMU / sama lebar). Set juga `table.columns[i].width`, tambahkan `w:tblLayout type=fixed`, dan `w:tblW` eksplisit. Cek hasilnya: `[c.width for c in t.columns]` harus `[1065530, 180340, 4485640]` (1695/285/7305 twips) — kalau ketiganya sama, tabel belum di-fix.
- `d.paragraphs` melewatkan paragraf kosong yang menempel tabel dan tidak memberi urutan campur paragraf/tabel. Untuk memastikan urutan + indent persis: iterasi `d.element.body.iterchildren()`, bungkus `Paragraph(child, d)` / `Table(child, d)` sendiri, cetak `i, tag, text[:40], left_indent`.
- Cek highlight: loop semua run di paragraf DAN di setiap sel tabel, cetak yang `font.highlight_color == WD_COLOR_INDEX.YELLOW`. Yang harus kuning: nomor, Tempat (sekaligus italic), setiap `[...]`.
- `scripts/docx_validate.py` dari bundled docx skill dipakai untuk health-check paket (`{"ok": true}`). Bundled docx skill = protected, jangan diedit; pakai saja script-nya.

## references & scripts
- `references/spesifikasi-docx.md` — precise docx spec (twips, font, highlights) + python-docx build notes + render check + kontrol panjang halaman.
- `references/sumber-data-weekly-kksi.md` — peta deck "OJK Weekly Report" (scorecard, incident, EDR, DAM, SAST, F5, pengadaan) ke butir bagian III + jebakan periode campur.
- `scripts/extract_pptx_facts.py` — dump isi .pptx vendor (text, tabel, gambar) sebagai acuan angka.
