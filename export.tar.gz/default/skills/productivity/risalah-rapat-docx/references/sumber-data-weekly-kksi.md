# Deck "OJK Weekly Report" → butir bagian III

Deck mingguan ini rekuren. `read_file` pada PDF-nya mengembalikan teks+tabel berurutan; jangan hanya andalkan transkrip/catatan user untuk angka.

## Peta bagian
| Bagian slide | Jadi butir III tentang | Angka yang diambil |
|---|---|---|
| Security Scorecard | skor keamanan + faktor skor | skor total (mis. 98/100), grade, tanggal capture |
| Incident Investigation (blok tabel per insiden) | insiden periode ini | jam deteksi/eskalasi/blocking, rentang resolved, nomor INC, PIC |
| Email Quarantine | email quarantine + DLP | total quarantine, total release, %, jumlah DLP |
| Temuan DAM | DAM | jumlah database, % kelulusan, total temuan, pecahan major/critical, area (configuration/privilege) |
| Pantau Database penting | prioritas monitoring | nama sistem (SIMFOSIA, OJKSAR, SIPENA) + kandidat perluasan |
| Temuan SAST | SAST | jumlah aplikasi dipindai, jumlah baris dianalisis, jumlah finding |
| Upgrade F5 | upgrade F5 | jumlah target + pecahan per lokasi, versi OS lama→baru, CVE, timeline per hari |
| Temuan EDR + Status Week-N | EDR mingguan | jumlah threat, pecahan endpoint user/server, false positive/benign/true positive, klasifikasi malware/ransomware/backdoor/rootkit |
| Summary EDR Triwulan | ringkasan triwulan | total alert, jumlah endpoint terdampak, kategori teratas, top jabatan |
| Score Compliance Cloud | skor cloud | skor per provider (GCP/AWS IAAS & SAAS) |
| Laporan Weekly & Monthly Vendor + Ticket | pengadaan | vendor, perangkat, nomor kontrak |
| Tiket Pekerjaan (Red/Blue/Product Team) | kegiatan tim | nama orang + daftar pekerjaan (masuk risalah hanya kalau rapat membahasnya) |

## Jebakan berulang
- **Periode campur dalam satu deck.** Scorecard menyebut satu periode, DAM/preview menyebut periode lain, EDR "Week-N", insiden menyebut tanggal spesifik. Jangan paksa satu periode untuk semua butir: tulis periode di butir yang bersangkutan, dan cantumkan periode agenda sebagai ASUMSI di chat (placeholder kalau ragu).
- **Deck mengutip rapat sebelumnya.** Slide timeline upgrade menyebut "Berdasarkan keputusan rapat <tanggal>" — itu bukan keputusan rapat ini; jangan tulis sebagai hasil rapat sekarang.
- **Jumlah target harus dijumlahkan.** Rincian per lokasi wajib menjumlah ke total yang disebut slide; kalau catatan user beda satu angka, tulis versi slide dan laporkan selisihnya di chat.
- **Slide ringkasan vs slide detail bisa beda angka** (mis. jumlah temuan di matriks vs di judul). Ambil angka dari tabel/slide detail, sebut konteksnya.
- **Rapat koordinasi internal KKSI tidak punya pihak vendor**: semua butir bagian III pakai satu paragraf `Terkait <topik>, ...` (pola contoh KKSI di `contoh-rr`), bukan hierarki `1./a./i.`. Decknya tetap dipakai untuk angka.
- **Timeline pelaksanaan upgrade bisa punya hari "jeda"** (change freeze karena pekerjaan lain) — jangan ditulis sebagai hari upgrade.
