# Spesifikasi .docx + catatan build

## Spec values (PRD §5)
- A4: page 11906 × 16838 twips (EMU = twips × 635). Margins 1440 twips (2,54 cm) all sides.
- Font: Bookman Old Style, 11 pt, hitam; proofing id-ID; isi justify; line spacing 1,5 (line=360); para spacing 0 (judul) / 0–8 pt (isi).
- Bold nowhere, incl. headings. No emoji. No tables in body sections.
- Kop: 3 baris rata tengah spacing 1,0: "RISALAH RAPAT", kosong, "NOMOR RR-<urutan>/MS.1300/<tahun>" with yellow highlight.
- Meta table: 3 kolom tanpa border, cell left/right margin 100 twips, widths 1695 / 285 / 7305 twips. Rows: Hari, Tanggal | Waktu | Tempat (miring + highlight kuning) | Pemimpin Rapat | Agenda.
- Section left indents (twips): I/II = 709; III level 1 = 1134, level 2 = 1560, level 3 = 1985; IV = 1134.
- Headings KAPITAL, no bold, Roman I–IV sequential, aligned.

## python-docx build notes
- Section size/margins: `section.page_width/page_height/margins` in twips.
- Highlight: `run.font.highlight_color = WD_COLOR_INDEX.YELLOW`.
- Italic: `run.italic = True`.
- Line spacing 1,5: `paragraph_format.line_spacing = 1.5`.
- Indent twips: `paragraph_format.left_indent = Twips(n)` from `docx.shared`.
- Borderless table: python-docx default ('Table Normal') has no borders — do not apply a grid style.
- Column width: `cell.width = Twips(n)` per column.
- Meta table GOTCHA: rows adalah 4-tuple `(label, value, highlight, italic)` tapi tabel punya 3 kolom — kolom tengah ISINYA pemisah " : ", BUKAN `row[1]`. Saat loop `for j, cell in enumerate(row.cells)` jangan index tuple dengan `j` (`add_run(row[j])` → TypeError 'bool' object is not iterable saat j=1). Pakai: `add_run(row[j] if j == 0 else (" : " if j == 1 else row[1]))`.
- Time format: `16:00 – 17:00 WIB` (24h, colon, en dash with spaces, WIB suffix).

## Render check before delivery (PRD §9)
Render .docx ke PDF/image via Word COM (pywin32) — soffice/libreoffice TIDAK terpasang di host ini.

### Word COM recipe (page count + PDF)
```python
import win32com.client, os
word = win32com.client.DispatchEx("Word.Application")
word.Visible = False
try:
    doc = word.Documents.Open(r"D:\HERMES\RR\X.docx", ReadOnly=True)
    pages = doc.ComputeStatistics(2)          # 2 = wdStatisticPages
    out = r"D:\HERMES\RR\_preview.pdf"
    doc.SaveAs2(out, FileFormat=17)           # 17 = wdFormatPDF
    doc.Close(False)
    print("pages:", pages)
finally:
    word.Quit()
```
Page count dari Word adalah pengukuran sebenarnya (≥ font metrics). Sering kali lebih besar dari estimasi: 2 halaman rapat mingguan yang terlihat ringkas tetap dihitung 3 oleh Word. Jadi jangan percaya estimasi — selalu ukur.

### Page-length control
Normal 1–2 halaman A4. Kalau > 2 halaman:
1. Ukur dulu — jangan potong isi sebelum tahu berapa overflow (lihat Word COM di atas).
2. Temukan PARAGRAF mana yang bocor ke halaman 3, bukan cuma jumlah halamannya: `doc.Paragraphs(i).Range.Information(3)` = nomor halaman paragraf (3 = wdActiveEndPageNumber). Loop semua paragraf, cetak `pg | text[:60]`. Tanpa ini, kompresi jadi menebak-nebak; dengan ini, tahu persis berapa baris yang perlu dihemat.
3. Rapatkan dulu (murah, tidak mengubah isi): heading `line_spacing=1.5→1.0`, `space_before=8→0`, `space_after=0` untuk heading+body, dan HAPUS paragraf kosong sebelum heading I (contoh asli juga langsung PEMBUKAAN setelah tabel meta). Setelah heading rapat, overflow sering tinggal 1–3 baris.
4. Baru ringkas isi: gabung butir bertetangga satu topik (sematkan CVE ke butir versi; sematkan tiket+log+backup+absensi jadi satu butir), buang frasa pengisi ("saat ini", "telah", "yang mencapai"), satu kalimat per fakta. Butir directive KKSI juga boleh digabung (pakai satu "mohon ... , mohon ... , dan mohon ...").
5. Ulangi ukur setelah SETIAP perubahan — Word COM ~5 detik, jauh lebih murah daripada delivery 3 halaman. Jangan pernah klaim "2 halaman" tanpa `ComputeStatistics(2)` terakhir.

### Rekonsiliasi transkrip ↔ PPT (kasus nyata yang berulang)
PPT hampir selalu lebih benar untuk angka. Pola selisih yang sudah terbukti: versi ditranskrip "7.15/7.17" → PPT `7.1.5/7.1.7`; jumlah IP "14.600/14.000" → PPT `14.605`; bandwidth transkrip menyebut angka tak konsisten adalah BURUK, PPT punya DUA angka sah yang berbeda konteks (peak sliding window 10 menit vs laporan harian) — jangan pilih satu, tulis keduanya dengan konteksnya masing-masing; rincian incident "known 4 vs 7" → ambil tabel PPT (critical/suspicious × acknowledged/unacknowledged); jam absensi keluar "5.47/7.00" → tabel PPT; "integrasi taxi" → nama vendor/feed sebenarnya di slide (mis. Cyble) — pakai istilah PPT, jangan fonetik transkrip.

Bila user mengirim PPT SETELAH risalah jadi: jangan tulis ulang dari nol dan JANGAN tulis ulang script build penuh — `patch` butir-butir yang selisih di script build yang sudah ada, hapus placeholder yang kini terjawab, isi Agenda dari tabel kontrak di slide PPT, lalu ukur ulang halaman (butir yang diisi angka bisa jadi lebih pendek/panjang). Placeholder yang tetap tak terjawab PPT tetap `[...]` (mis. penyebab kendala internal penyedia).

Bila Word COM tidak tersedia: JANGAN klaim render-check selesai — lakukan verifikasi struktural via python-docx sebagai pengganti (assertions pada `sections[0]` page 210×297 mm / margin 25.4 mm, `styles["Normal"]` Bookman Old Style 11 pt, loop paragraf mencetak alignment/left_indent/highlight/italic untuk heading dan butir). Render visual tidak dilakukan → sebutkan di chat sebagai keterbatasan, jangan disembunyikan.

### Kosakata target (bukan kata lisan)
Transkrip kacau sering menghasilkan: "dokteris" → tidak jelas, jangan ditebak → `[...]` + laporkan; "di-knowledge ada 4, yang di-knowledge ada 7" → dua klaim bertentangan → placeholders untuk jumlah tiap kategori. Untuk angka yang terdengar beda di dua tempat (bandwidth "76.22 GBPS" vs "747.56 gbps") → placeholder + lapor selisih. Jam absensi "jam 7.00, jam 5.47, 28.00, 21.00" → pasti kacau → `[...]` untuk jam keluar.
