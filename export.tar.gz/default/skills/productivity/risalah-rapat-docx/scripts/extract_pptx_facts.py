# -*- coding: utf-8 -*-
"""Dump isi .pptx vendor (text frame, tabel, gambar) sebagai acuan angka risalah.

Pakai:  python scripts/extract_pptx_facts.py "<path.pptx>"
Output: per slide, semua teks + tabel (baris dipisah ' | ') + nama gambar.
Tabel slide adalah sumber angka paling andal (versi, incident, SLA, backup, absensi)
dan sering memuat data yang tidak disebut di transkrip rapat.
"""
import sys

from pptx import Presentation


def dump(path):
    prs = Presentation(path)
    print("slides:", len(prs.slides))
    for i, slide in enumerate(prs.slides, 1):
        print(f"\n===== SLIDE {i} =====")
        for shape in slide.shapes:
            if shape.has_text_frame:
                txt = "\n".join(p.text for p in shape.text_frame.paragraphs if p.text.strip())
                if txt.strip():
                    print("[TXT]", txt)
            if shape.has_table:
                print("[TABLE]")
                for row in shape.table.rows:
                    print(" | ".join(c.text.strip() for c in row.cells))
            if shape.shape_type == 13:  # PICTURE
                try:
                    print("[PIC]", shape.image.filename)
                except Exception:
                    print("[PIC]")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    dump(sys.argv[1])
