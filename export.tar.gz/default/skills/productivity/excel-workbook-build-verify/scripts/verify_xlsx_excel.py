#!/usr/bin/env python3
"""Verify a generated .xlsx really opens and computes.

Copies the target to a temp file, opens it headlessly through Excel COM
(Windows + pywin32), forces a full rebuild, scans every used cell for
error values, probes named cells, then closes without saving.

Prints JSON. Exit 0 = opened and no error cells found.

    python verify_xlsx_excel.py out.xlsx
    python verify_xlsx_excel.py out.xlsx --probe RINGKASAN!C19 --probe DASHBOARD!B7

When Excel COM is unavailable, falls back to LibreOffice: PDF conversion
succeeds only if the file was actually openable.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile

ERRORS = ("#VALUE!", "#REF!", "#NAME?", "#DIV/0!", "#N/A", "#NUM!", "#NULL!")


def scan_excel(path, probes):
    import win32com.client as w32

    tmp = os.path.join(tempfile.gettempdir(), "_verify_" + os.path.basename(path))
    shutil.copy2(path, tmp)

    out = {"engine": "excel", "opened": False, "errors": [], "probes": {}, "sheets": []}
    xl = w32.DispatchEx("Excel.Application")
    xl.Visible = False
    xl.DisplayAlerts = False
    wb = None
    try:
        wb = xl.Workbooks.Open(tmp)
        out["opened"] = True
        out["sheets"] = [s.Name for s in wb.Worksheets]
        xl.CalculateFullRebuild()
        for ws in wb.Worksheets:
            used = ws.UsedRange
            vals = used.Value
            if vals is None:
                continue
            if not isinstance(vals, tuple):
                vals = ((vals,),)
            r0, c0 = used.Row, used.Column
            for i, row in enumerate(vals):
                if not isinstance(row, tuple):
                    row = (row,)
                for j, v in enumerate(row):
                    s = str(v)
                    if s.startswith("#") and s in ERRORS:
                        out["errors"].append(
                            {"sheet": ws.Name, "row": r0 + i, "col": c0 + j, "value": s})
        for p in probes:
            sheet, _, cell = p.rpartition("!")
            try:
                out["probes"][p] = wb.Worksheets(sheet).Range(cell).Value
            except Exception as exc:  # noqa: BLE001 - report, do not fail
                out["probes"][p] = "PROBE_FAILED: %s" % exc
    finally:
        if wb is not None:
            try:
                wb.Close(SaveChanges=False)
            except Exception:  # noqa: BLE001
                pass
        try:
            xl.Quit()
        except Exception:  # noqa: BLE001
            pass
    return out


def check_libreoffice(path):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return {"engine": "none", "opened": None,
                "note": "Excel COM unavailable and LibreOffice not installed"}
    outdir = tempfile.mkdtemp(prefix="xlsxpdf_")
    proc = subprocess.run(
        [soffice, "--headless", "--convert-to", "pdf", path, "--outdir", outdir],
        capture_output=True, text=True, timeout=300)
    pdfs = [f for f in os.listdir(outdir) if f.lower().endswith(".pdf")]
    ok = bool(pdfs) and os.path.getsize(os.path.join(outdir, pdfs[0])) > 0
    return {"engine": "libreoffice", "opened": ok,
            "stdout": proc.stdout.strip()[:400], "stderr": proc.stderr.strip()[:400],
            "note": "PDF produced => file was openable"}


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path")
    ap.add_argument("--probe", action="append", default=[],
                    help="SHEET!CELL to read, repeatable (e.g. RINGKASAN!C19)")
    args = ap.parse_args()

    if not os.path.exists(args.path):
        print(json.dumps({"error": "not found: %s" % args.path}))
        return 2

    try:
        result = scan_excel(args.path, args.probe)
    except ImportError:
        result = check_libreoffice(args.path)

    result["clean"] = result.get("opened") is True and not result.get("errors")
    print(json.dumps(result, indent=2, default=str))
    return 0 if result["clean"] else 1


if __name__ == "__main__":
    sys.exit(main())
