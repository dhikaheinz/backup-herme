---
name: excel-workbook-build-verify
description: Use when a generated .xlsx must really open and compute.
version: 1.0.0
metadata:
  hermes:
    tags: [excel, xlsx, xlsxwriter, openpyxl, verification, win32com, libreoffice]
    category: productivity
    related_skills: [xlsx, docx, pdf]
---

# Excel Workbook Build + Verify

Use when writing a Python script that generates a non-trivial .xlsx
(many sheets, cross-sheet formulas, Excel Tables, dropdowns,
conditional formatting, charts) and the file must be handed to a human
who will open it in Excel.

## Procedure

1. **Pick the writer deliberately.**
   - `xlsxwriter`: rich styling, native tables, dropdowns,
     conditional formats, charts. Write-once — it cannot edit or
     re-open a workbook.
   - `openpyxl`: read, verify, patch, and small edits. Does not
     round-trip charts (saving a charted workbook drops the charts).
   - Large styled build: `xlsxwriter` for the build, `openpyxl` only
     for inspection afterwards.
   - Never hand-write sheet XML.
2. **Keep the build in a re-runnable script**, one file, `write_file`
   it, then `python build_x.py` from the project dir. A script that
   rebuilds the whole workbook from a spec beats surgical edits when
   the workbook is generated anyway — you can re-run until clean.
3. **Guard every formula.** Never concatenate a formula string inline.
   Route it through one helper that asserts the double quotes are
   balanced and rejects an `=` followed by whitespace or `,` with no
   string literal around it:

   ```python
   _BAD = []
   def F(formula):
       if formula.count('"') % 2:
           _BAD.append(("unbalanced quotes", formula))
       import re
       for m in re.finditer(r'=\s*[,\s]', formula):
           seg = formula[max(0, m.start()-40):m.end()+20]
           if '"' not in seg[len(seg)//2:]:
               _BAD.append(("quote-less literal", formula))
               break
       return "=" + formula if not formula.startswith("=") else formula
   ```

   At the end of the build, raise if `_BAD` is non-empty. A formula
   that lost its quotes (`=IF(B4= ,,B4-C4)` instead of
   `=IF(B4="","",B4-C4)`) is valid XML and invalid Excel — the file
   gets rejected with a generic "cannot be opened" and no visible
   cause. Fail the build instead of shipping it.
4. **Force recalculation on load.** Neither writer computes anything.
   Set the workbook's full-calc-on-load flag so the human sees numbers
   instead of blank formula cells:
   - xlsxwriter: `workbook.set_calc_mode("auto")` plus the
     full-calc-on-load flag, or post-process the saved file's
     `calcPr` element to add `fullCalcOnLoad="1"`.
   - openpyxl: `--recalc` in the bundled `xlsx` skill's
     `xlsx_edit.py`.
5. **Verify by opening it in a real spreadsheet app, on a copy.**
   XML/zip validation is not enough: `ET.fromstring` on every part can
   pass on a file Excel rejects.
6. **Isolate failures by generating minimal probes, not by staring
   at the XML.** Build one tiny synthetic workbook per feature group
   — plain cells, native table, data validation with a defined
   name, conditional formatting, hyperlink, chart, structured
   references, empty formula result — and ask Excel to open each.
   Whichever set all fail points at a component shared by every
   failure (usually the formulas or the styles, since those are
   always present). This is minutes of work and beats bisecting a
   40 KB file by hand.
7. **Check the arithmetic invariants, not just for errors.** Before
   delivering, assert the numbers reconcile: total row equals the sum
   of its parts, the summary sheet equals the source sheet it
   references, and with no hard quotes entered the projection equals
   the estimate. Print both sides in the verification output so the
   comparison is in the transcript.
8. **Test interactivity for real, then undo it.** Change a dropdown
   value, select one vendor quote, log one payment, edit one input —
   confirm the dashboard, colors and totals move — then revert the
   test data. A workbook that only looks right is unverified.

## Deliverable Conventions

- All user-facing workbook text is in the user's language (Indonesian
  for this user), terse and specific. Notes columns carry operational
  facts ("butuh fitting 2-3 kali, lead time 4-6 bulan"), never filler
  that repeats on 29 of 40 rows.
- Never write a placeholder number as if it were a quote. Keep an
  input sheet as the only place the user types, leave undecided
  values blank, and add a `SUMBER` column (`TEMPLATE` / `QUOTE` /
  `ESTIMASI SENDIRI`) so the share of the budget still on template
  numbers is visible as a percentage on the dashboard.
- Separate budget areas that must not be summed together (honeymoon vs
  the event) with a distinct tier excluded from the main total, and
  show both totals.
- One source of truth per fact: payments logged in one sheet and
  pulled by `SUMIFS` everywhere else; quotes kept in one table with a
  `DIPILIH?` flag that feeds the chosen price. Two places to type the
  same number is a bug waiting to be reported.

## Lessons (from Lamaran_Planner.xlsx build, Okt 2026)

- **Structured refs must equal table header text exactly.** Headers like `PROYEKSI (IDR)` with formulas referencing `[PROYEKSI]` build valid XML but every structured ref resolves to `#REF!` after Excel opens it. Generate headers and bracket refs from one Python list.
- **`freeze_panes(0, 0)` can make Excel reject the whole file** with the generic "Open method of Workbooks class failed". Only pass freeze_panes for a real frozen row/col.
- Bisecting an un-openable build: strip whole top-level statements via AST spans (line-based filters break on continuation lines), one sheet section at a time, then one feature group. Every probe opened in real Excel COM — XML/zip checks pass on files Excel rejects.
- Recalc + read `c.Text` over the used range, assert expected strings. `Evaluate()` on structured refs returns HRESULT codes, not values.
- `ExportAsFixedFormat` fails without a printer (spooler disabled here); fallback = scan all cells for `####` after recalc.

## References

- `scripts/verify_xlsx_excel.py` — headless Excel recalc + error scan,
  JSON output.
