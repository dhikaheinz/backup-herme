---
name: notion-database-management
description: "Manage Notion databases for meeting and rakor summaries."
version: 0.1.0
author: Hermes
platforms: [windows]
metadata:
  hermes:
    tags: [Notion, Productivity, Database, API, Windows]
---

# Notion Database Management

Manage two Notion databases under **📁 OJK — Task Hub**: **📋 Ringkasan Rapat** and **📋 Ringkasan Rakor**. Create, update, and query entries for meeting and coordination summaries.

## When to Use
- When you need to **create a new entry** in either database.
- When you need to **verify existing entries** in a database.
- When you need to **understand the structure** of the databases.
- When you need to **move or archive** entries between databases (user-initiated only).

## Prerequisites
- **Notion API Key**: Stored in `C:/Users/Administrator/AppData/Local/hermes/.env` as `NOTION_API_KEY`.
- **Notion Integration**: Must be shared with the target databases.
- **Hermes Environment**: Load the `.env` file before running scripts:
  ```bash
  set -a && . "$LOCALAPPDATA/hermes/.env" && set +a
  ```

## Databases Overview

| Database | db_id | ds_id | Jenis Select Options |
|---|---|---|---|
| 📋 Ringkasan Rapat | d3a9f345-a0c6-40cb-8c0a-188180e3fc2a | c29884fa-8e9a-406d-b1d5-fb40c4b233a1 | SOC, NDR, Internal, Lainnya |
| 📋 Ringkasan Rakor | 11cd214f-0deb-41b6-ba18-247474ba4b95 | 6b6ee0fa-b9f0-47ff-ba67-7baf4e1e71b9 | Mingguan, Bulanan, Khusus, Lainnya |

Both databases share the following properties:
- `Judul` (title)
- `Tanggal` (date)
- `Peserta` (multi-select)
- `Sumber` (select: Transkriptor)
- `Status` (select: Draf, Ditinjau, Final)
- `Jumlah Action Item` (number)

## How to Run

### Create a New Entry

Invoke through the `terminal` tool:
```bash
cd /d/HERMES/Notion && cp "summary.md" body.md && set -a && . "$LOCALAPPDATA/hermes/.env" && set +a && python notion_summary.py \
  --judul "DD MMM YYYY — Risalah Rapat|Rakor <Topik>" \
  --tanggal YYYY-MM-DD --jenis <Jenis> --peserta "A,B" --body body.md
```

### Verify Entries

Invoke through the `terminal` tool:
```bash
cd /d/HERMES/Notion && python view_all.py
```

### Move or Archive Entries

Invoke through the `terminal` tool:
```bash
cd /d/HERMES/Notion && python move_entry.py --source_db_id <source_db_id> --target_db_id <target_db_id> --entry_id <entry_id>
```

## Quick Reference

| Command | Description |
|---|---|
| `notion_summary.py` | Create a new entry in a database. |
| `view_all.py` | View all entries in a database. |
| `create_db.py` | Create a new database. |
| `move_entry.py` | Move or archive an entry between databases. |

## Procedure

### Create a New Entry

1. Write the summary in `body.md` using the fixed template.
2. Run `notion_summary.py` with the required arguments.
3. Verify the entry was created successfully.

### Verify Entries

1. Run `view_all.py` to see all entries in the database.
2. Check the details of each entry.

### Move or Archive Entries

1. Identify the entry ID to move or archive.
2. Run `move_entry.py` with the source and target database IDs.
3. Verify the entry was moved or archived successfully.

## Pitfalls

- **Duplicate Entries**: Ensure the `Judul` and `Tanggal` combination is unique before creating a new entry.
- **API Limits**: Notion API has a limit of 2000 characters per rich text block and 100 blocks per request.
- **Database Structure**: Ensure the correct database is targeted based on the type of meeting or rakor.
- **Null Values**: Avoid null values in properties that require them, such as `icon` in blocks.

## Verification

To verify that an entry was created successfully, run:
```bash
cd /d/HERMES/Notion && python view_all.py
```

Check if the entry appears in the list with the correct details.