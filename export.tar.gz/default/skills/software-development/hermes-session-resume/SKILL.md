---
name: hermes-session-resume
description: "Resume a specific Hermes CLI session by ID from terminal."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [hermes, cli, session, resume, terminal]
---

# Resume a Hermes CLI Session

When a Hermes CLI session is disconnected (e.g. editor closed, terminal crashed), reconnect to the same session by ID.

## Procedure

1. **List all sessions** to find the session ID:
   ```bash
   hermes sessions list
   ```
   Output shows Title, Workspace, Last Active, and ID columns (e.g. `20260920_092045_439bb2`).

2. **Resume by ID** with the `--resume` flag:
   ```bash
   hermes chat --resume <SESSION_ID>
   ```
   Example:
   ```bash
   hermes chat --resume 20260920_092045_439bb2
   ```

3. **Resume the most recent session** (no ID needed):
   ```bash
   hermes chat --continue
   ```

4. **Resume into the TUI** (interactive terminal UI):
   ```bash
   hermes chat --resume <SESSION_ID> --tui
   ```

## Pitfalls

- **`--resume` requires an argument.** Running `hermes chat --resume` without an ID returns an error. If you don't know the ID, run `hermes sessions list` first or use `--continue` to grab the latest.
- **Session ID format is `YYYYMMDD_HHMMSS_<6hex>`** — if the user gives a partial ID, confirm against `hermes sessions list` before passing it.