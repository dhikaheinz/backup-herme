---
name: github-private-auth
description: "Auth to private GitHub repos via SSH/PAT without gh CLI."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [github, auth, ssh, pat, remote]
---

# GitHub Private Repo Auth (No CLI)

When `gh` CLI is not installed, push to private GitHub repositories using native git auth (SSH or Personal Access Token).

## Method 1: SSH (Recommended)

1. Check for existing key: `ls -la ~/.ssh/id_rsa` or `ls -la ~/.ssh/id_ed25519`
2. Generate if missing: `ssh-keygen -t ed25519 -C "your_email@example.com" -N ""`
3. Read the public key: `cat ~/.ssh/id_ed25519.pub`
4. User must manually add this public key to GitHub Settings -> SSH and GPG keys.
5. Set remote: `git remote add origin git@github.com:<username>/<repo>.git`
6. Push: `git push -u origin main`

## Method 2: Personal Access Token (PAT)

1. User generates a PAT in GitHub Settings -> Developer Settings -> Personal access tokens (Tokens classic) with `repo` scope.
2. User provides the PAT to the agent.
3. Set remote: `git remote add origin https://<username>:<token>@github.com/<username>/<repo>.git`
4. Push: `git push -u origin main`

## Pitfalls

- **Do not assume SSH keys exist.** Always check `~/.ssh/` first. If missing, generate and explicitly prompt the user to upload the public key to GitHub before pushing.
- **Do not print the PAT.** If using HTTPS auth, accept the token from the user, set the remote, but never log `git remote -v` if it contains the token in plaintext.