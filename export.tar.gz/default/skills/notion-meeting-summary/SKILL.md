---
name: notion-meeting-summary
description: "Transkriptor transcript → Notion meeting summary page."
version: 1.0.0
---

# Notion Meeting Summary

Summarize Transkriptor meeting transcript → new Notion page.
Full PRD: `D:/HERMES/Notion/PRD.md`. Read it if edge-case handling needed.

## Workflow

1. Read transcript (paste, .txt, .docx). Optional: PPT/PDF for context only.
2. Clean typos / speech-to-text artifacts from context. Never change meaning.
3. Extract: topics, decisions, action items, risks, open questions.
4. Write summary in fixed template (below).
5. Dedupe: query Notion DB for same Judul+Tanggal. Exists → stop, report, no new page.
6. Create page. Return Notion link + list of [perlu dicek] flags.

## Notion access (Windows, this machine)

- Token: `NOTION_API_KEY` in `C:/Users/Administrator/AppData/Local/hermes/.env`
- Load: `set -a && . "$LOCALAPPDATA/hermes/.env" && set +a && python script.py`
- API version header: `2025-09-03`. Databases vs data_sources are separate endpoints; query via `/v1/data_sources/{id}/query`.
- Under page `3ebe5b8d-6408-81ce-857b-dfe8b5c5a8f1` (📁 OJK — Task Hub). "Dhika" page (`054e...`) is a profile page — rejects content.
- Creating DB: POST `/v1/databases` (not `/data_sources`), then PATCH `/v1/data_sources/{ds_id}` to add properties. Cannot add a second title prop; rename default `Name` to `Judul`.

## Target databases — USER CHOOSES, never auto-move

| | 📋 Ringkasan Rapat | 📋 Ringkasan Rakor |
|---|---|---|
| db_id | d3a9f345-a0c6-40cb-8c0a-188180e3fc2a | 11cd214f-0deb-41b6-ba18-247474ba4b95 |
| ds_id | c29884fa-8e9a-406d-b1d5-fb40c4b233a1 | 6b6ee0fa-b9f0-47ff-ba67-7baf4e1e71b9 |
| Jenis select | Jenis Rapat (SOC/NDR/Internal/Lainnya) | Jenis Rakor (Mingguan/Bulanan/Khusus/Lainnya) |

Both present Judul/Tanggal/Peserta/Sumber/Status/Jumlah Action Item.
Use Ringkasan Rapat for rapat (meeting). Ringkasan Rakor for rakor (coordination meeting). Ask user if unsure — do NOT move pages between DBs unless explicitly told.
- `notion_summary.py` targets Ringkasan Rapat (cached in `.notion_ids.json`). For Rakor: copy script, set DB_ID/DS_ID to Rakor ids.

## Properties schema

| Properti | Tipe | Note |
|---|---|---|
| Judul | title | `[Jenis Rapat] - [Topik] - YYYY-MM-DD` |
| Tanggal | date | meeting date |
| Jenis Rapat | select | SOC, NDR, Internal, Lainnya |
| Peserta | multi_select | from metadata or transcript |
| Sumber | select | Transkriptor |
| Status | select | always Draf on create |
| Jumlah Action Item | number | count from summary |

Verify property names against real DB before first use; create DB if absent.

## Template (all sections always present, empty = "Tidak ada")

```
## Ringkasan Singkat
(3-5 sentences: context + main outcome)

## Poin Pembahasan
- Topic
  - point

## Keputusan
- ...

## Action Item
| Tugas | Penanggung Jawab | Tenggat | Status |
|---|---|---|---|

## Risiko dan Kendala
- ...

## Pertanyaan Terbuka
- ...
```

## Rules (hard)

- Only facts from transcript. No invented names/numbers/dates.
- Unclear audio → mark `[perlu dicek]`, never guess.
- One point = one idea, max 2 sentences.
- Action item must have tugas + penanggung jawab + tenggat; missing → "Belum ditentukan".
- Decisions vs proposals: separate.
- Bahasa Indonesia baku. Keep technical terms (SOC, NDR, DLP) as-is.
- Sensitive data (passwords, tokens, API keys, personal data, internal IPs) → `[DISENSOR]`. Never to Notion.
- Empty/unreadable transcript → stop, report, no page.
- Notion API limits: 2000 chars per rich_text, 100 blocks per request. Long content → split, never truncate.
- Same transcript resubmitted → no duplicate page (dedupe step 5 handles).
- Judul format: `DD MMM YYYY — <Risalah Rapat|Rakor> <Topik>`. Contoh: `09 Okt 2026 — Risalah Rapat NDR Darktrace: Assessment Sizing`. Status awal: Draf.
- Reading blocks then writing back fails validation unless sanitized: drop null `icon`/`children`/`id`/timestamps, `numbered_list_item` drop `list_format`, `meeting_notes`/`transcription` → paragraph, `table` needs table_width + has_column_header + has_row_header + table_row children fetched from block's /children endpoint. Working code: `migrate_pages.py` (sanitize_block).
