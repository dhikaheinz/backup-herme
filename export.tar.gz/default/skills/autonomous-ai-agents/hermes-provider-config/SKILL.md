---
description: "Use when setting Hermes provider/router via CLI."
name: hermes-provider-config
---

# Hermes provider config (CLI)

This user's Hermes home = `$HERMES_HOME` = `C:\Users\Administrator\AppData\Local\hermes`. A stale leftover config lives at `~/.hermes` (`C:\Users\Administrator\.hermes`) — ignore it; it only confuses `hermes doctor` output.

## Procedure — point Hermes at a router (e.g. 9router)

1. Key goes in .env, never config.yaml (secrets in .env, settings in config.yaml):
   ```bash
   ENV=$(hermes config env-path)
   echo 'OPENAI_API_KEY=*** >> "$ENV"
   echo 'OPENAI_BASE_URL=http://localhost:20128/v1' >> "$ENV"   # when overriding default endpoint
   ```
2. Point model config at the router:
   ```bash
   hermes config set model.provider openai-api
   hermes config set model.base_url http://localhost:20128/v1   # 9router
   hermes config set model.default paid                          # any model ID the router serves
   hermes config set model.api_mode codex_responses             # routers exposing /v1/responses
   ```
   `api_mode: chat_completions` only when the router lacks the Responses API. 9router has it — use `codex_responses`. Interactive alternative: `hermes model` picker. Alias for quick switching: `hermes config set model.aliases.<name> 'custom/<vendor>/<model>'` then `/model <name>` in chat.

## Verify the switch (in order)

```bash
hermes config get model                                      # provider / base_url / api_mode
grep -E '^(OPENAI_BASE_URL|OPENAI_API_KEY)' "$(hermes config env-path)"   # key present
curl -s "$BASE_URL/v1/models" | head -c 300                  # live: router's model list = real endpoint
hermes status                                                 # Provider + masked key prefix
```
Then one live `hermes chat -q "test"` and check `tail "$HERMES_HOME"/logs/gateway.log` — the request must hit `<base_url>/v1/responses` or `/v1/chat/completions`, never api.openai.com.

## Pitfalls

- `hermes doctor` message "model.provider '<p>' is set but no API key is configured (add it to ~/.hermes/.env)" can be a FALSE POSITIVE. Doctor hardcodes the display path (`_DHH` → `~/.hermes`) in its message but the runtime resolves keys via `load_env()` → `get_env_path()` → `$HERMES_HOME/.env`. Before trusting the warning: compare `hermes config path`, `hermes config env-path`, and `echo $HERMES_HOME`. Key present in the real .env + `curl` to base_url OK = runtime fine; the warning names whichever path doctor displays, not necessarily the path it reads.
- `openai-api` provider resolves the key from `OPENAI_API_KEY` only, preferring `.env` over parent-shell env (`get_env_value_prefer_dotenv`) — so a `.env` edit always beats a stale shell export; put fixes in `.env`, not `export`. No key-prefix validation for this provider (fail-open), so a malformed key produces opaque 401s at call time, not a doctor warning.
- Multiple profiles: each profile under `$HERMES_HOME/profiles/<name>/` carries its own config.yaml/.env and model settings — set and verify per active profile, not just the default one. This user's kz-* profiles all point at 9router (`openai-api`, `localhost:20128/v1`, `codex_responses`).
- Live proof beats config reading: `/v1/models` returning the router's own model IDs (e.g. `paid`, `openrouter/...:free`) is the end-to-end signal the key + base_url are wired to the router.
