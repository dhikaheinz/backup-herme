## Description:

Comprehensive UI design skill covering fundamentals, patterns, and anti-patterns for layout, typography, color, spacing, accessibility, motion, and component design.

This skill is ready for commercial/non-commercial use.

## Publisher:

[wpank](https://clawhub.ai/user/wpank)

### License/Terms of Use:


## Use Case:

Developers, designers, and agents use this skill to design, review, and refine web interfaces, including components, pages, dashboards, landing pages, accessibility, responsive behavior, and visual hierarchy.

### Deployment Geography for Use:

Global

## Known Risks and Mitigations:

Risk: The documented installer command uses an unpinned executable installer and mutable remote source.

Mitigation: Review the installer and source before execution, prefer a pinned package version or immutable commit, and run installation without elevated privileges or unrelated credentials.

## Reference(s):

- [UI Design Skill Page](https://clawhub.ai/wpank/skills/ui-design)
- [Publisher Profile](https://clawhub.ai/user/wpank)

## Skill Output:

**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance]

**Output Format:** [Markdown with prose, tables, checklists, and inline code examples]

**Output Parameters:** [1D]

**Other Properties Related to Output:** [May include UI design recommendations, CSS examples, implementation checklists, and installation commands.]

## Skill Version(s):

1.0.0 (source: frontmatter and server release metadata)

## Ethical Considerations:

Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment.
