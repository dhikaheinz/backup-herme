---
name: python-pptx-design
description: Use when designing professional decks with python-pptx.
version: 1.0.0
---

# High-Quality PowerPoint Design with python-pptx

This skill defines the workflow and design standards for programmatically generating presentation decks that strictly follow professional UI design systems (such as AfrexAI UI Design System) and pass quality audits (Anti-Slop / Visual Verification).

## Core Principles & Design System Integration

1. **Slide Dimensions**: Always default to 16:9 widescreen format (`13.333` x `7.5` inches).
2. **Color Palette**:
   - Primary dark / brand color for dark slides/headers (e.g. Navy `#123B63` / `#040C16`).
   - Semantic status colors for callouts: Success (green `#237A57`), Warning (amber `#D97706`), Error (red `#A62B2B`), Info (blue `#3B82F6`).
   - Subtle background tints for cards (`#EFF7F2`, `#FFF2F2`, `#EFF6FF`).
   - Neutrals: Crisp contrast background (`#F9FAFB`), dark body text (`#1F2933`).
3. **Typography & Hierarchy**:
   - Header title: 28–36pt bold.
   - Section subheadings / Card titles: 14–18pt bold.
   - Body text: 12–14pt regular (minimum 11pt for small tables/footers).
   - Monospace for logs, Splunk SPL, code, or terminal commands (`Consolas` or `Courier New`).
4. **Layout Patterns**:
   - **Header Bar**: Standard dark top bar on light content slides (`height=1.15"`).
   - **Footer Bar**: Tracking ID, classification, and page numbers on every slide.
   - **Process / Flow**: Chevron process shapes aligned horizontally with matching numbered steps below.
   - **Cards / Containers**: Rounded rectangles with left accent bars (`width=0.06"`) for elevated information hierarchy.
   - **Comparison / Multi-Column**: 2–4 equal width columns with distinct status colors.

## Workflow & Step Sequence

### Step 1: Script Architecture
Write a standalone Python generator script using `python-pptx` (or extend `pptx_create.py`).
Define explicit design tokens (colors, fonts, margins, card dimensions) at the top of the script.

### Step 2: Content Layout & Positioning Rules
- **Margins**: `MARGIN = Inches(0.75)`, `CONTENT_W = W - 2*MARGIN` (~11.833 inches).
- **Text Box Padding & Wrapping**: Set `tf.word_wrap = True` on every text frame.
- **Code Blocks & SPL Queries**:
  - Keep SPL / code block text concise and formatted across multiple short lines.
  - Set code font size to 9.5–10pt monospace.
  - Calculate text length vs width to prevent horizontal truncation inside the container shape.
- **Chevron Process Diagrams**:
  - Keep chevron labels short (e.g., 2–3 words, using explicit line breaks `\n`).
  - Ensure labels on chevrons match the titles of detailed step descriptions below them word-for-word.

### Step 3: Visual Verification (Mandatory Quality Gate)
Never deliver a deck blindly. Verify visual output:

1. **Export Slides to PNG**:
   Use Windows COM (`win32com.client.Dispatch("PowerPoint.Application")`) or LibreOffice + `pdftoppm`:
   ```python
   import win32com.client
   app = win32com.client.Dispatch("PowerPoint.Application")
   pres = app.Presentations.Open(r"D:\path\to\deck.pptx", WithWindow=False)
   pres.SaveAs(r"D:\path\to\preview_dir", 18) # 18 = ppSaveAsPNG
   pres.Close()
   app.Quit()
   ```
2. **Inspect via Vision Analysis**:
   Inspect key slides (Cover, Complex Tables, Flow Diagrams, Code Blocks) with `vision_analyze`.

3. **Audit Checklist**:
   - [ ] **No Text Overlap**: Text does not cross decorative lines, background shapes, or neighboring text frames.
   - [ ] **No Truncation**: Code blocks and long table cells fit entirely inside their containers.
   - [ ] **Semantic Alignment**: Labels in diagram shapes (e.g., chevrons) match the detailed list below.
   - [ ] **Readability & Contrast**: Text contrast passes WCAG AA against background card fills.

## Pitfalls & Lessons

- **Text Frame Overlap with Decorative Lines**: When placing decorative accent lines near text titles, ensure the line's Y-coordinate sits strictly below or above the title text frame bounding box.
- **Horizontal Truncation in Monospace Code Containers**: Long code strings without spaces (e.g., Splunk queries with multiple `OR` statements) will overflow dark container boxes if font size > 10pt or lines aren't broken. Use shorter Splunk syntax (e.g., `IN (...)`) or break lines before pipe (`|`) operators.
- **Chevron vs List Label Mismatches**: When rendering a 7-step chevron process flow above a 7-step detailed list, synchronize step titles between the chevron text and the detailed list header to prevent audience confusion.
