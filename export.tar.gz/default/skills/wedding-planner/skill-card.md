## Description:

Plan weddings with budget guardrails, guest-list scenarios, vendor scorecards, payment tracking, and deadline-driven coordination.

This skill is ready for commercial/non-commercial use.

## Publisher:

[ivangdavila](https://clawhub.ai/user/ivangdavila)

### License/Terms of Use:

MIT-0

## Use Case:

External users planning weddings use this skill to organize budget commitments, guest-list scenarios, vendor comparisons, RSVP status, milestone timelines, and day-of coordination notes. It is suited for couples, family organizers, planners, and coordinators who want structured trade-offs and a local planning record.

### Deployment Geography for Use:

Global

## Known Risks and Mitigations:

Risk: Persistent wedding-planning notes may contain budgets, guest-list scenarios, vendor notes, deadlines, and family context.

Mitigation: Use persistent memory only after user approval, keep notes local under ~/wedding-planner/, and avoid storing payment credentials, full contracts, IDs, or deeply personal details unless explicitly necessary.

Risk: Budget, vendor, RSVP, or timeline suggestions could affect real commitments if treated as final decisions without review.

Mitigation: Confirm before changing notes tied to live contracts, deposits, final guest communication, or day-of coordination, and keep decisions logged with trade-offs and unresolved risks.

## Reference(s):

- [Wedding Planner Skill Page](https://clawhub.ai/ivangdavila/skills/wedding-planner)
- [Wedding Planner Homepage](https://clawic.com/skills/wedding-planner)

## Skill Output:

**Output Type(s):** [Markdown, Guidance, Configuration, Files]

**Output Format:** [Markdown notes, tables, checklists, scorecards, timelines, and concise planning guidance]

**Output Parameters:** [1D]

**Other Properties Related to Output:** [May create or update opt-in local planning notes under ~/wedding-planner/.]

## Skill Version(s):

1.0.0 (source: frontmatter and release evidence)

## Ethical Considerations:

Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment.
