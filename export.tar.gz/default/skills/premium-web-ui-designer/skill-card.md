## Description:

Improves websites and web apps with clearer layout, stronger visual hierarchy, modern UI styling, responsive checks, and polished frontend design guidance or code changes.

This skill is ready for commercial/non-commercial use.

## Publisher:

[nano20926](https://clawhub.ai/user/nano20926)

### License/Terms of Use:

MIT-0

## Use Case:

Developers, designers, and product teams use this skill to critique, redesign, or polish frontend interfaces for websites, dashboards, SaaS products, landing pages, portfolios, and interactive tools.

### Deployment Geography for Use:

Global

## Known Risks and Mitigations:

Risk: The skill may be invoked broadly for web UI polish or redesign requests.

Mitigation: Confirm that proposed visual and code changes fit the user's requested scope before accepting them.

Risk: Frontend redesign work can unintentionally affect accessibility, semantics, or responsive behavior.

Mitigation: Preserve semantic HTML and accessible labels, then check at least one desktop and one mobile viewport before delivery.

## Reference(s):

- [Web Style Directions](references/web-style-directions.md)

## Skill Output:

**Output Type(s):** [text, markdown, code, shell commands, configuration, guidance]

**Output Format:** [Markdown prose with design rationale, implementation notes, code changes, command suggestions, and responsive verification notes when applicable]

**Output Parameters:** [1D]

**Other Properties Related to Output:** [May include screenshot-based visual validation notes when the agent can inspect rendered frontend output.]

## Skill Version(s):

1.0.0 (source: server release metadata)

## Ethical Considerations:

Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment.
