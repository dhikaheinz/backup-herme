## Description:

This skill helps agents review AI-generated content for low information density, generic phrasing, weak originality, unverified success claims, unnecessary structure, and template-like writing before publication or sharing.

This skill is ready for commercial/non-commercial use.

## Publisher:

[futurizerush](https://clawhub.ai/user/futurizerush)

### License/Terms of Use:

MIT-0

## Use Case:

Developers, writers, and agents use this skill to review draft AI-generated content for originality, evidence, information density, and verified completion claims before publishing, submitting, or sharing it.

### Deployment Geography for Use:

Global

## Known Risks and Mitigations:

Risk: The skill can apply strong writing-style preferences during broad pre-publication review.

Mitigation: Override or narrow the review criteria when a specific tone, format, audience, or publication standard is required.

## Reference(s):

- [ClawHub skill page](https://clawhub.ai/futurizerush/skills/antislop)
- [Publisher profile](https://clawhub.ai/user/futurizerush)

## Skill Output:

**Output Type(s):** [text, markdown, guidance]

**Output Format:** [Markdown review guidance and concise text recommendations]

**Output Parameters:** [1D]

**Other Properties Related to Output:** [No code execution, credential handling, persistence, or external tool use is described by the artifact.]

## Skill Version(s):

0.1.0 (source: server release metadata and SKILL.md frontmatter)

## Ethical Considerations:

Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment.
