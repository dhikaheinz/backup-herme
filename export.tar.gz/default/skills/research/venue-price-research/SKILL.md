---
name: venue-price-research
description: "Use when researching Indonesian venue prices with sources."
version: 0.1.0
---

# Venue Price Research (Indonesia)

Research and compare wedding/event venue & paket prices, usually cheap options in Jabodetabek,
with a source link on every figure. Deliverable: per-row-sourced markdown tables in casual
Indonesian (user's language) plus a caveats block. Terse, no pleasantries, no unsolicited advice.

## Procedure

1. **Vendor price-list pages first, blog articles second.** Blog/SEO posts only give generic market
   ranges ("gedung sederhana Rp10-25 jt"). Useful numbers live on vendor pages. Query patterns:
   `<vendor> paket wedding <kota> 2026 harga`, `<kota> harga sewa gedung pernikahan murah`,
   then `web_extract` the vendor page(s). Run several searches in parallel — the keyless search
   backend fails ~1 in 3 queries (see Pitfalls).

2. **Decode the price convention before quoting.** Different per vendor; quoting the wrong end of a
   range is the main failure mode:
   - **Jagarasa `Rentang harga: RpA - RpB`** = Intimate 100 pax (low) .. Mewah 800 pax (high).
     NOT the 500-pax price. State this when the user sizes for 500 pax.
   - **Mantenbaru struck-through prices** = active promo; quote both numbers, label promo.
   - **pernikahan.or.id pages**: "Harga tersambung" = live/synced; "Referensi historis" = archive,
     not an active offer. Label archived figures as such.
   - **Bundling "all-in"** = venue + venue charges + crew transport/accommodation + catering, dekor,
     MUA, dokumentasi, MC, entertainment, WO. **Excludes** PPN 11%, PB1, overtime, extra pax, and the
     outside-catering charge (often 10%). Say so.
   - Some chains sell only whole bundles — no venue-only. Name them and route venue-only asks elsewhere.

3. **Build the tables.** Split by kota, then venue-only vs all-in <pax> (never mixed — it inflates
   the cheap end). Every row hyperlinks its source. End with a "termurah per kebutuhan" summary
   (venue only / akad <=150 pax / all-in 200 / all-in 500 / all-in 800-1000).

4. **Caveats block, always:** publication year of the price, promo vs list, PPN/PB1 excluded,
   weekend +20-50% vs weekday, DP/booking-fee schedule when known. If a number is not published
   (e.g. venue-only prices in Depok), say so plainly — never substitute a blog estimate.

5. **Offer one drill-down** (current prices for a named venue list) as a single closing question.

## Sources cheat-sheet

| Source | What it gives |
|---|---|
| `jagarasa.com/product/paket-wedding-di-<venue>` | per-venue: range, capacity, facilities, inclusions, DP terms |
| `jagarasa.com/product-category/.../paket-wedding-<kota>/` | whole city list, one row per venue |
| `tigadaracatering.id/price-list-bundling-gedung` | one long table: venue, kota, all-in 500 pax |
| `dewiweddings.com/2023/05/pernikahan-500-gedung.html` | bundling per kota — old brochure, historical |
| `mantenbaru.com/harga-detail/...`, `/vendors/<venue>` | per-pax tiers, promos, payment schedule, venue-only |
| `harumsaricatering.id/paket-wedding` | 599-venue Jabodetabek directory |
| `pernikahan.or.id/paket-wedding-di-<venue>-update-<year>` | venue index per kota, live-vs-archived labels |
| `lamudi.co.id/journal/gedung-pernikahan-di-<kota>` | venue-only "mulai dari" prices |

## Pitfalls

- **SEO-farm placeholder tables.** Some aggregator articles ship template rows — "Gedung Serbaguna
  ABC", "[Lanjutkan hingga 20 Gedung]". Not venues: cite only their range figures, never the rows.
- **Keyless search 403s are transient.** Re-issue the query with different wording; do not conclude
  search is unavailable. Same for `web_extract` on a category page: the product URL often extracts
  when the category 403s.
- **WooCommerce pages**: prices are often in the listing markup, which survives extraction better
  than the product body — try the listing/category URL when a product page comes back empty.
- **Aggregators restate each other.** One figure appearing on three sites is one source; confirm on
  the venue's or vendor's own page before calling it corroborated.
- Compare current-year vendor pages against the older bundling tables (2023-era brochures): expect
  ~8-12%/yr drift; always lead with the newest figure.

## Related

- `wedding-planner` (hub skill, protected) owns budget/vendor-scorecard workflow — this skill only
  does the cited price research feeding it.
- `grounded-citations` if the deliverable is a formal document needing a ledger-backed Sources block.
