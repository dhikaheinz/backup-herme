## Description:

Plan and manage any event from start to finish, including timelines, task checklists, vendors, volunteers, and budgets.

This skill is ready for commercial/non-commercial use.

## Publisher:

[chris](https://clawhub.ai/user/chris)

### License/Terms of Use:

MIT-0

## Use Case:

External users use this skill to plan and manage parties, conferences, weddings, fundraisers, retreats, and other organized events. It helps track event records, task checklists, vendors, helpers, budgets, status summaries, and post-event wrap-up.

### Deployment Geography for Use:

Global

## Known Risks and Mitigations:

Risk: Local event records can include names, vendor contacts, budgets, venue details, and notes.

Mitigation: Avoid storing highly sensitive personal details, and periodically review or delete old event-data.json records.

## Reference(s):

- [ClawHub Skill Page](https://clawhub.ai/chris/skills/event-planner-os)
- [README](artifact/README.md)
- [CHANGELOG](artifact/CHANGELOG.md)

## Skill Output:

**Output Type(s):** [text, markdown, files, configuration, guidance]

**Output Format:** [Markdown responses with structured JSON event records stored locally]

**Output Parameters:** [1D]

**Other Properties Related to Output:** [Maintains event records, task lists, vendor details, volunteer assignments, and budget totals in event-data.json.]

## Skill Version(s):

1.0.1 (source: frontmatter, changelog, server release metadata)

## Ethical Considerations:

Users should evaluate whether this skill is appropriate for their environment, review any generated or modified files before relying on them, and apply their organization's safety, security, and compliance requirements before deployment.
