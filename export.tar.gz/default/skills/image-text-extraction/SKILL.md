---
name: image-text-extraction
description: Read text in images via native Windows OCR (no vision).
---

# Image text extraction without vision

## Gate

- Call vision_analyze once on the image. If it reports the model has no vision, do NOT ask the user to retype or describe the image — run local OCR.
- Never retry vision_analyze after a no-vision result; the gap is model-level, not image-level. Go straight to the script.

## Procedure

1. Resolve the script path via skill_view(name='image-text-extraction') (linked_files lists scripts/win-ocr.ps1).
2. Run it on the image path:

   ```
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File "<scripts>/win-ocr.ps1" "C:\path\to\image.png"
   ```

   Output: one recognized text line per stdout line.
3. Answer the user's question from the extracted text, not from a description of what the image "probably" shows.

## Pitfalls

- Go native first. The Hermes venv python has no pip and package registries may be unreachable from this host, so tesseract/pytesseract/rapidocr installs fail or hang. Native WinRT OCR needs zero installs and reads UI screenshots well.
- A workspace copy at D:\HERMES\ocr.ps1 may also exist; it is the same script. Prefer the skill copy — the workspace can change, the skill persists.
- The engine falls back to en-US when the user's profile languages have no OCR pack. If output is garbage on non-Latin text, say so plainly; do not invent contents.
- Accuracy is validated on UI screenshots (menus, pricing pages, dialogs, marketing banners). Do not claim handwriting or photo accuracy without testing it first.
