# Per-family bypass strategy

Auto-detect family from the model name, then apply the strategy. When a strategy fails, escalate down the list (only on refusal).

| Tier | Family | Strategy order | Notes |
|------|--------|----------------|-------|
| S | Claude | system prompt + **prefill** → boundary inversion → refusal inversion | Assistant prefill is the strongest lever; Claude is the only family that supports it well |
| A | DeepSeek, Qwen, Yi, some Grok | system prompt only | Already loose by default; often no injection needed |
| B | GPT-4/5, Gemini, most Grok | system prompt → refusal inversion → prefill → Parseltongue | Input classifier + output filter layered; single prompt usually not enough |
| C | frontier-strict (e.g. GPT-5 strict, latest Gemini) | race models, weight-level abliteration | Prompt-only bypass is unreliable; treat as adversarial |

## Escalation ladder (per query, only on refusal)

1. Plain request (baseline).
2. System prompt already injected — no extra action.
3. Parseltongue obfuscation at `standard` tier (leetspeak, unicode homoglyph, bubble) to evade input-side classifiers.
4. `heavy` tier (base64, hex, multi-layer) if standard fails.
5. Race N models (`ULTRAPLINIAN`), score on quality + filteredness + speed, take least-filtered. Cost is N× — reserved, not default.
6. For open-weight models with a GPU: weight-level abliteration is permanent and beats every prompt trick. Prompt-level techniques do nothing against frontier output filters.

## Family detection

Match case-insensitively on the model name: `claude` → S; `deepseek|qwen|yi|gemma` → A; `grok` → A/B; `gpt-4|gpt-5|o1|o3` → B; `gemini` → B; unknown → treat as B (cautious).
