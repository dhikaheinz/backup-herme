# Gateway inject recipes (New API / one-api family)

One-api family gateways sit between Hermes and the upstream provider and expose two injection mechanisms. Both inject a system message; Hermes does not send one, so the inject always applies.

## Mechanism 1 — Channel System Prompt (preferred)

Admin panel → Channels → Edit channel → Advanced Settings → **System Prompt** field. Paste the jailbreak prompt. Applies to every request routed through that channel. Repeat per channel (Claude, GPT, Gemini, Grok). This is the cleanest: one edit per channel, survives Hermes config changes and direct API calls.

Behavior: the gateway does NOT override a system message the client already sent (user priority). Since Hermes sends none, injection always happens.

## Mechanism 2 — Parameter Override (`operations` array)

Field: **Parameter Override** (per channel), advanced operation JSON. Prepends a system message to the messages array:

```json
{
  "operations": [
    {
      "path": "messages",
      "mode": "prepend",
      "value": [
        { "role": "system", "content": "<JAILBREAK PROMPT>" }
      ]
    }
  ]
}
```

`prepend` on an array inserts elements at the front. Use this when the channel System Prompt field is unavailable, or when you need conditional logic (`conditions` array, `logic: AND`) to target a subset of requests.

Supported `mode` values for `operations`: `set`, `delete`, `move`, `append`, `prepend`, `copy`, `trim_prefix`, `trim_suffix`, `ensure_prefix`, `ensure_suffix`, `trim_space`, `to_lower`, `to_upper`, `replace`, `regex_replace`.

## Verify the deployment, not the field

Panel field availability varies by version. Confirm the running version via the gateway's own version endpoint, and confirm the field exists in the admin UI before telling the user it can be done.

## Layering with Hermes

Gateway inject (primary) + Hermes `personalities.<name>.system_prompt` (backup) = coverage whether or not the call goes through the gateway. Both are system-message injects, so both survive context compression and pass to subagents.
