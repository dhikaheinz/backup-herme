---
name: threat-intel-lookups
description: Use when building IOC lookup scripts from free sources.
---

# Threat-intel reputation lookups (no API key)

Build IOC reputation checkers (file hash first; same pattern extends to IP/domain/URL) that chain multiple free sources into one verdict. Output scale: GreenFlag (verified benign), YellowFlag (suspicious or UNVERIFIED), RedFlag (detected malicious).

## Procedure

1. Probe candidate sources BEFORE writing client code. One live request per source with known-malicious and known-benign test values; keep only sources that return 200. Ground truth:
   - Malicious: EICAR test file — md5 `44d88612fea8a8f36de82e1278abb02f`, sha1 `3395856ce81f2b7382dee72602f798b642f14140`, sha256 `275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f`
   - Benign: sha256 of empty file `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`, sha256 of `"hello"` `2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824`
2. Write the script to the exact folder the user names with write_file — files on disk are the deliverable; a pasted code block is not a delivery. Include a sample input `.txt` with the ground-truth hashes.
3. Run the script end-to-end on the sample input and show the real output before reporting done.
4. Ship verdict logic from `templates/hash_scan.py`; pick sources per `references/free-sources.md`.

## Standing rules

- Lookup failure is never clean: 429/5xx/timeout/unknown → `YellowFlag (UNVERIFIED)` or cap the run and skip the source. Parsing a rate-limit response as "0 detections" produces false GreenFlags — the worst failure mode of a reputation tool.
- Require positive benign evidence for GreenFlag: whitelist validation, hit in a known-software catalog (NSRL/CIRCL). Absence of detections alone = YellowFlag — unknown ≠ safe.
- Aggregate across sources: any source reporting a detection → RedFlag. Conflicting signals escalate to YellowFlag, never silently resolved.
- Retry rate limits with backoff (2s, 4s, ...), cap per-run queries below the documented hourly limit, keep worker counts low on per-request sources.
- Validate input: lowercase, hex regex `{32,40,64}`, dedupe preserving order; print raw/duplicate-skipped/invalid counts and save invalid lines to a separate file so the user can fix format.
- Ignore CIRCL `KnownMalicious: malshare.com` — it fires for benign entries in the `nsrl_legacy` catalog (mass false positive); only trust other KnownMalicious sources.

## Templates

- `templates/hash_scan.py` — proven 3-source hash scanner (Team Cymru MHR + CIRCL + OTX), copy and modify.

## References

- `references/free-sources.md` — working no-key sources with exact endpoints, quirks, rate limits, and dead ends.
