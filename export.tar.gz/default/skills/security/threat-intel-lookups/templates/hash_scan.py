# hash_scan.py — free no-key hash reputation scanner (copy & modify)
# 3 cross-check sources, verdict gabungan:
#   1. Team Cymru MHR    -> % deteksi AV global (bulk 1 koneksi, no limit)
#   2. CIRCL hashlookup  -> katalog NSRL known-software (no limit)
#   3. AlienVault OTX    -> AV engine + YARA + pulse (limit ~100/jam -> cap 90)
# Logika: deteksi manapun = RedFlag | whitelist/katalog = GreenFlag | >=10 pulse = YellowFlag
#         gagal/unknown di semua sumber = YellowFlag (UNVERIFIED) — JANGAN pernah hijau.

import sys
import os
import re
import time
import socket
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://otx.alienvault.com/api/v1/indicators/file/{}"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
    "Accept": "application/json",
}
WORKERS = 3          # OTX limit per-jam per-IP -> worker sedikit
RETRIES = 2          # retry 429/5xx dengan backoff
OTX_MAX_PER_RUN = 90 # cap di bawah limit 100/jam; sisanya pakai MHR+CIRCL saja
MHR_HOST = "hash.cymru.com"
MHR_PORT = 43
MHR_BATCH = 500      # max hash per query MHR
CIRCL_BATCH = 100    # max hash per request bulk CIRCL

GREEN, YELLOW, RED, RESET = "\033[92m", "\033[93m", "\033[91m", "\033[0m"
HASH_RE = re.compile(r"^[0-9a-f]{32}$|^[0-9a-f]{40}$|^[0-9a-f]{64}$")


def hash_type(h):
    return {32: "MD5", 40: "SHA1", 64: "SHA256"}.get(len(h))


def otx_check(h):
    """Return (av_detections, pulse_count, whitelist). 429/5xx = retry, tetap gagal -> raise."""
    av, pulses, whitelist = [], 0, False
    last_err = None
    for attempt in range(RETRIES):
        try:
            ra = requests.get(BASE.format(h) + "/analysis", headers=HEADERS, timeout=30)
            rg = requests.get(BASE.format(h) + "/general", headers=HEADERS, timeout=30)
            if ra.status_code == 429 or rg.status_code == 429 or ra.status_code >= 500:
                last_err = f"HTTP {ra.status_code}/{rg.status_code} (rate limit OTX)"
                time.sleep(2 * (attempt + 1))   # backoff
                continue
            if ra.status_code == 200:
                a = ra.json().get("analysis") or {}
                for name, plug in (a.get("plugins") or {}).items():
                    res = plug.get("results") or plug.get("result") or {}
                    det = res.get("detection") if isinstance(res, dict) else None
                    if not det:
                        continue
                    if isinstance(det, str):
                        av.append(det)
                    elif isinstance(det, list):
                        for x in det:
                            if isinstance(x, dict) and x.get("rule_name"):
                                av.append(x["rule_name"])
            if rg.status_code == 200:
                g = rg.json()
                pulses = (g.get("pulse_info") or {}).get("count", 0)
                vnames = [v.get("name", "") for v in (g.get("validation") or []) if isinstance(v, dict)]
                whitelist = any(("whitelist" in n.lower()) or ("empty" in n.lower()) for n in vnames)
            return av, pulses, whitelist
        except Exception as e:
            last_err = e
    raise RuntimeError(f"OTX gagal {RETRIES}x: {last_err}")


def mhr_bulk(hashes):
    """Team Cymru MHR: {hash: percent}. percent=None = NO_DATA (belum pernah dilihat AV)."""
    out = {}
    for i in range(0, len(hashes), MHR_BATCH):
        batch = hashes[i:i + MHR_BATCH]
        for attempt in range(3):
            try:
                s = socket.create_connection((MHR_HOST, MHR_PORT), timeout=25)
                s.sendall(b"begin\n" + "\n".join(batch).encode() + b"\nend\n")
                data = b""
                while True:
                    try:
                        c = s.recv(65536)
                    except socket.timeout:
                        break
                    if not c:
                        break
                    data += c
                s.close()
                for line in data.decode(errors="ignore").splitlines():
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = line.split()
                    if len(parts) >= 3:
                        out[parts[0].lower()] = None if parts[-1] == "NO_DATA" else int(parts[-1])
                break
            except Exception:
                if attempt == 2:
                    pass  # MHR down -> lanjut pakai OTX saja
    return out


def circl_bulk(hashes):
    """CIRCL bulk (hanya md5 & sha1): {hash: record}."""
    out = {}
    for typ in ("md5", "sha1"):
        sub = [h for h in hashes if (len(h) == 32 and typ == "md5") or (len(h) == 40 and typ == "sha1")]
        for i in range(0, len(sub), CIRCL_BATCH):
            batch = sub[i:i + CIRCL_BATCH]
            for attempt in range(3):
                try:
                    r = requests.post(f"https://hashlookup.circl.lu/bulk/{typ}",
                                      json={"hashes": batch}, timeout=30)
                    if r.status_code == 200:
                        for rec in r.json():
                            key = (rec.get("MD5") or rec.get("SHA-1") or "").lower()
                            if key:
                                out[key] = rec
                    break
                except Exception:
                    if attempt == 2:
                        pass
    return out


def circl_lookup(h):
    """CIRCL individual (untuk SHA256). Return record atau None (404=unknown)."""
    try:
        r = requests.get(f"https://hashlookup.circl.lu/lookup/sha256/{h}",
                         headers=HEADERS, timeout=30)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return None


def check(h, mhr_pct, circl_rec, use_otx=True):
    """Gabung 3 sumber -> (flag, info). use_otx=False = MHR+CIRCL saja (lewat cap OTX)."""
    av, pulses, whitelist = [], 0, False
    if use_otx:
        try:
            av, pulses, whitelist = otx_check(h)
        except RuntimeError as e:
            if mhr_pct is not None and mhr_pct > 0:
                return "RedFlag", f"MHR deteksi {mhr_pct}% (OTX limit, tidak di-query)"
            km = ((circl_rec or {}).get("KnownMalicious") or "").strip()
            if km and "malshare" not in km.lower():
                return "RedFlag", f"CIRCL KnownMalicious={km} (OTX limit)"
            return "YellowFlag", f"UNVERIFIED ({e})"

    mhr_txt = f"MHR={mhr_pct}%" if mhr_pct is not None else "MHR=NO_DATA"
    circl_txt = "CIRCL=known" if circl_rec is not None else "CIRCL=unknown"

    # 1) deteksi AV dari OTX atau MHR percent -> RedFlag
    if av or (mhr_pct is not None and mhr_pct > 0):
        src = []
        if av:
            src.append("OTX-AV: " + "; ".join(av[:3]))
        if mhr_pct is not None and mhr_pct > 0:
            src.append(f"MHR deteksi {mhr_pct}%")
        return "RedFlag", f"{' | '.join(src)} | {circl_txt} | pulses={pulses}"
    # 2) whitelist OTX -> GreenFlag
    if whitelist:
        return "GreenFlag", f"whitelisted/empty | {mhr_txt} | {circl_txt} | pulses={pulses}"
    # 3) CIRCL: ada record = file dikenali katalog NSRL; malshare.com = noise -> diabaikan
    if circl_rec is not None:
        km = (circl_rec.get("KnownMalicious") or "").strip()
        fn = circl_rec.get("FileName", "")
        if km and "malshare" not in km.lower():
            return "RedFlag", f"CIRCL KnownMalicious={km} ({fn[:40]}) | {mhr_txt} | pulses={pulses}"
        if pulses < 10:
            return "GreenFlag", f"ada di katalog NSRL/CIRCL ({fn[:40]}) | {mhr_txt} | pulses={pulses}"
    # 4) dilaporkan di banyak pulse tapi 0 deteksi -> YellowFlag
    if pulses >= 10:
        return "YellowFlag", f"dilaporkan di {pulses} pulse | {mhr_txt} | {circl_txt}"
    # 5) tidak ada data dari sumber mana pun -> YellowFlag (tidak bisa dipastikan aman)
    return "YellowFlag", f"NO DATA di 3 sumber (hash tidak dikenal / limit API) | {mhr_txt} | {circl_txt}"


def load_hashes(path):
    raw, ok, invalid, dup = 0, [], [], 0
    seen = set()
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            raw += 1
            t = line.split()[0].lower()
            if HASH_RE.match(t):
                if t in seen:
                    dup += 1
                else:
                    seen.add(t)
                    ok.append(t)
            else:
                invalid.append(line)
    return raw, ok, invalid, dup


def main():
    folder = os.path.dirname(os.path.abspath(__file__))
    arg = sys.argv[1] if len(sys.argv) > 1 else input("Nama file txt berisi hash: ").strip()
    path = arg if os.path.isabs(arg) else os.path.join(folder, arg)
    if not os.path.isfile(path):
        print(f"File tidak ditemukan: {path}")
        sys.exit(1)

    raw, hashes, invalid, dup = load_hashes(path)
    print(f"Baris baca     : {raw}")
    print(f"Hash valid     : {len(hashes)} (duplikat di-skip: {dup})")
    if invalid:
        inv_path = os.path.join(folder, "invalid_lines.txt")
        with open(inv_path, "w", encoding="utf-8") as f:
            f.write("\n".join(invalid) + "\n")
        print(f"Baris invalid  : {len(invalid)} (disimpan: {inv_path})")

    print("Sumber 1: Team Cymru MHR (bulk, 1 koneksi)...")
    mhr = mhr_bulk(hashes)
    print("Sumber 2: CIRCL hashlookup (bulk md5/sha1 + per-hash sha256)...")
    circl = circl_bulk(hashes)
    sha256s = [h for h in hashes if len(h) == 64]
    with ThreadPoolExecutor(max_workers=10) as ex:
        for h, rec in zip(sha256s, ex.map(circl_lookup, sha256s)):
            if rec is not None:
                circl[h] = rec
    print(f"Sumber 3: OTX per-hash (cap {OTX_MAX_PER_RUN} hash, {WORKERS} thread, retry {RETRIES}x)...")

    results = {}
    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        futs = {}
        for idx, h in enumerate(hashes):
            use_otx = idx < OTX_MAX_PER_RUN
            futs[ex.submit(check, h, mhr.get(h), circl.get(h), use_otx)] = h
        done = 0
        for fut in as_completed(futs):
            h = futs[fut]
            results[h] = fut.result()
            done += 1
            print(f"\r  progres: {done}/{len(hashes)}", end="", flush=True)
    print("\r" + " " * 30 + "\r", end="")

    counts = {"GreenFlag": 0, "YellowFlag": 0, "RedFlag": 0}
    out_path = os.path.join(folder, f"results_{os.path.basename(path)}")
    color = {"GreenFlag": GREEN, "YellowFlag": YELLOW, "RedFlag": RED}
    print("Hasil:")
    with open(out_path, "w", encoding="utf-8") as out:
        for h in hashes:
            flag, info = results[h]
            counts[flag] += 1
            line = f"{flag}  {h} [{hash_type(h)}]  ({info})"
            out.write(line + "\n")
            print(f"{color[flag]}{line}{RESET}")

    print(f"\nGreenFlag  : {counts['GreenFlag']}")
    print(f"YellowFlag : {counts['YellowFlag']}")
    print(f"RedFlag    : {counts['RedFlag']}")
    print(f"Tersimpan  : {out_path}")


if __name__ == "__main__":
    main()
