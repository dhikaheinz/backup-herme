# Free no-key IOC sources — endpoints, quirks, dead ends

Re-probe before use; services change auth requirements without notice.

## Working (no API key)

### Team Cymru MHR (Malware Hash Registry)
- Whois protocol over TCP: `hash.cymru.com:43`.
- Bulk: send `begin\n<one hash per line>\nend\n`; response lines `hash epoch percent` or `hash epoch NO_DATA`; percent > 0 = seen malicious by AV telemetry. Mixed md5/sha1/sha256 in one query is fine. Batch ~500 per connection.
- Read the response with recv until close OR socket.timeout — a blocking recv without timeout handling hangs.
- No key, no documented limit, very fast. Use as source #1 (covers the whole file in one connection).

### CIRCL hashlookup (NSRL software catalog)
- `GET https://hashlookup.circl.lu/lookup/{md5|sha1|sha256}/{hash}` — 200 = record (known software), 404 = not in catalog.
- Bulk exists ONLY for md5 and sha1: `POST /bulk/md5`, `POST /bulk/sha1`, body `{"hashes": [...]}`, ~100/request; response array contains only found records. NO bulk for sha256 — use individual GETs (parallel 10, ~20 req/s OK).
- Record fields: `FileName`, `FileSize`, `db` (`nsrl_legacy`), `KnownMalicious`. Presence WITHOUT a real KnownMalicious source = strong benign evidence (file is in the NIST software reference set). `KnownMalicious: malshare.com` = noise, ignore.
- No key, generous limits.

### AlienVault OTX — file indicator
- `GET https://otx.alienvault.com/api/v1/indicators/file/{hash}/analysis` → `analysis.plugins` per-engine results; real AV: `clamav`, `msdefender` (`results.detection` string), `yarad` (list of `{rule_name}`).
- `GET .../{hash}/general` → `pulse_info.count` (community pulses), `validation[]` with names like `Whitelisted hash`, `Empty hash`.
- Accepts md5/sha1/sha256. Direct JSON, no recaptcha.
- Limit ~100 requests/hour per IP → cap runs ~90, retry 429 with backoff, ≤3 workers. Rate limit persists a while after exhaustion (not per-minute).

## Dead ends (require key or blocked)

| Source | Symptom |
|---|---|
| VirusTotal `/ui/files/{sha256}` (web GUI backend) | 429 `RecaptchaRequiredError` even with full browser headers + cookie jar |
| VirusTotal API v3 | 401 without key |
| MalwareBazaar `mb-api.abuse.ch` `get_info` | 401 `Unauthorized` — requires Auth-Key header |
| Hybrid Analysis `/api/v2/search/hash` | 403 "API key is missing" |
| MetaDefender `/v4/hash/` | 401 without key |
| Jotti | 404 — no public hash endpoint |
| ThreatMiner | Cloudflare 522 intermittent |
| urlscan.io `files.hash:` search | 200 but matches only its own scan corpus — near-always empty |
