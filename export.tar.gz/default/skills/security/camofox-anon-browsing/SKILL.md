---
name: camofox-anon-browsing
description: "Use when browsing anonymously past bot detection."
version: 1.0.0
platforms: [windows, linux, macos]
---

# Camofox Anonymous Browsing

Local REST browser server wrapping Camoufox (Firefox fork, C++-level fingerprint
spoofing). Beats Google/Cloudflare bot walls that block headless Chromium.
Bypasses bot detection legitimately — use only on targets you are authorized to test.

## Install (Windows, verified)

```bash
cd /d/HERMES && git clone --depth 1 https://github.com/jo-inc/camofox-browser.git
cd camofox-browser
```

`npm install` FAILS on two known blockers — fix both:

1. **`openclaw` devDependency requires Node >=24.16** (host runs Node 22).
   Never needed at runtime. Skip dev deps: `npm install --omit=dev`.
2. **`better-sqlite3` needs Visual Studio C++ build tools** (node-gyp).
   No source file imports it — only `tests/unit/nativeBinding.test.js`. Remove
   the line from `package.json` `dependencies` before installing.

```bash
# after removing better-sqlite3 from package.json:
npm install --omit=dev --no-audit --no-fund
# downloads Camoufox (~493MB) + GeoIP (~51MB), takes ~3-5 min
```

Then run it:

```bash
CAMOFOX_CRASH_REPORT_ENABLED=false node server.js   # background=true
curl -s http://127.0.0.1:9377/health
```

`/health` returns `{"ok":true,"engine":"camoufox","browserConnected":true,...}`
when live.

## Two access paths

**A. REST API directly** — most reliable. `cfx.py` helper in the repo dir wraps it:

```bash
python cfx.py health
python cfx.py open https://example.com --user anonA
python cfx.py macro @google_search "query" --user anonA
python cfx.py snap <tabId> --user anonA
python cfx.py click <tabId> e28 --user anonA
python cfx.py eval <tabId> "document.cookie" --user anonA
python cfx.py text <tabId> --user anonA
python cfx.py reset anonA        # wipe that identity entirely
```

Raw API shape: `POST /tabs {userId, sessionKey, url}` → `tabId`, then
`GET /tabs/{id}/snapshot?userId=`, `POST /tabs/{id}/click {userId, ref}`,
`POST /tabs/{id}/navigate {userId, url|macro, query}`, `POST /tabs/{id}/evaluate`.

`sessionKey` is REQUIRED on tab creation — omit it and you get
HTTP 400 `{"error":"userId and sessionKey required"}`.

**B. Hermes `browser_exec`** — `hermes config set browser.cloud_provider camofox --force`
+ `CAMOFOX_URL=http://127.0.0.1:9377` in `$HERMES_HOME/.env` (`HERMES_HOME` =
`$LOCALAPPDATA/hermes` on Windows, NOT `~/.hermes`).

## Anonymity model

**Different `userId` = different identity.** Own cookies, own localStorage, own
profile. Verified: cookie set on example.com under `userId=anonA` returns
`(EMPTY)` under `userId=anonB`. Rotate the userId for a fresh anon session;
`cfx.py reset <userId>` destroys one.

Fingerprint spoofing is always on: `navigator.webdriver` is `false`, UA is a
real Firefox string (not Headless), locale/timezone/WebGL/Canvas/AudioContext
are consistent per profile.

## Pitfalls

- **Google search macro silently falls back to DuckDuckGo** when Google refuses
  a datacenter IP: response carries `"fallbackFrom":"google"`. Direct
  navigation to `google.com/search?q=` DOES return real results — check
  `googleResultsAvailable`.
- **`POST /tabs` with `macro` gives `about:blank`.** Create the tab plain, then
  `POST /tabs/{id}/navigate` with the macro. Or use direct URL.
- Directory context: `camofox-browser/AGENTS.md` holds the full API surface —
  read it before guessing routes.
- Server is a long-lived background process. Restart after reboot:
  `cd camofox-browser && CAMOFOX_CRASH_REPORT_ENABLED=false node server.js`.
