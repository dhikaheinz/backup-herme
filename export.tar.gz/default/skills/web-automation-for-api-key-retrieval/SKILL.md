---
name: web-automation-for-api-key-retrieval
description: Automate browser login and scrape API keys from web console.
category: security
---

## Always-On Rules
- **Direct and Concise Communication**: Responses must be direct and concise, without pleasantries or unnecessary explanations.
- **Use Incognito Mode**: Always use incognito mode for sensitive web interactions to avoid conflicts with existing sessions or cookies.
- **Error Handling**: If a step fails due to network issues or missing dependencies, retry with alternative methods or inform the user.
- **Security**: Never expose or log sensitive information such as API keys, passwords, or tokens.
- **Backend Preference**: Prefer Playwright or Chromium-based automation tools for browser interactions.

## Procedure
1. **Install Required Dependencies**: Ensure Chromium and Playwright are installed.
   ```bash
   npx playwright install chromium
   ```

2. **Initialize Browser Session**: Use browser_exec to open a new tab.
   ```python
   new_tab(url)
   ```

3. **Wait for Page Load**: Ensure the page is fully loaded before proceeding.
   ```python
   wait_for_load()
   ```

4. **Identify Form Elements**: Use JavaScript evaluation to locate form elements by their attributes.
   ```python
   js('document.querySelector("selector").value')
   ```

5. **Fill Form Fields**: Automate filling in form fields using fill_input.
   ```python
   fill_input(selector, value)
   ```

6. **Handle Login and Authentication**: If login is required, fill in credentials and submit the form.
   ```python
   fill_input('input[name="email"]', 'user@example.com')
   fill_input('input[name="password"]', 'password')
   js('document.querySelector("button[type=\"submit\"]").click()')
   ```

7. **Navigate to Sensitive Pages**: Use goto_url to navigate to pages containing sensitive information.
   ```python
   goto_url('https://console.mistral.ai/api-keys')
   ```

8. **Extract Sensitive Data**: Use JavaScript to extract sensitive data such as API keys.
   ```python
   api_key = js('document.querySelector("input[data-testid='api-key']").value')
   ```

9. **Secure Data Handling**: Save extracted data securely and ensure it is not logged or exposed.
   ```python
   with open("mistral_api_key.txt", "w") as file:
       file.write(api_key)
   ```

10. **Error Handling and Retry Logic**: Implement retry logic for network issues or missing dependencies.

## Pitfalls
- **Network Issues**: Ensure stable internet connection. If network issues persist, use a VPN or check proxy settings.
- **Missing Dependencies**: Ensure all required dependencies (Chromium, Playwright) are installed.
- **Incorrect Selectors**: Use accurate selectors to locate form elements. Verify selectors using browser developer tools.
- **Security Risks**: Avoid logging sensitive data. Use secure storage methods.

## References
- **Browser Automation Selectors**: [references/browser-selectors.md](references/browser-selectors.md)
- **Script Template**: [scripts/automate_mistral_login.py](scripts/automate_mistral_login.py)