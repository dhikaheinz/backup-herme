---
name: risalah-rapat
description: Use when building risalah rapat from transcript + PPT/PDF. Default output plaintext in chat, not .docx.
---

# Risalah Rapat (plaintext in chat — default since PRD v1.2)

Authoritative PRD: `D:\HERMES\RR-N\PRD_Risalah_Rapat (2).md` (v1.2). Older `D:\HERMES\RR\PRD_Risalah_Rapat (1).md` describes the superseded docx-first flow. User drops each new PRD version into `D:\HERMES\RR-N\` — locate with search_files and read it fresh every request.

## Where the source files live (check first, don't hunt)
- Meeting folders are per-date: `D:\OJK\ORIENTASI\DPSI\RR Weekly\<DD-MM-YYYY>\` (weekly/Ndr/SOC/TI runs) and `D:\OJK\ORIENTASI\DPSI\RR RAKOR\<DDMMYYYY>\` (rakor). Each holds the deck(s) (.pptx/.pdf), the risalah .docx, the raw `*_rekaman_<epoch>.wav`, and `transkripsi_<label>_rekaman_<epoch>.txt`.
- The `.docx` files sitting next to an older `RISALAH RAPAT ...` name may be a previous output, not a source — read the `.pptx/.pdf` + `transkripsi_*.txt` as the actual inputs.
- Transcripts come from the local app `D:\ANTIGRAVITY\Transkirptor` (faster-whisper, offline). It never auto-saves: the user exports manually via a Save dialog, so files land wherever they chose, not in a fixed output dir. Its recorder default is `%TEMP%\stt_recording_<epoch>.wav` when not given a path.
- Outputs from `C:\Users\Administrator\NotulenKu` (`recordings/`, `exports/`) are a separate other tool — normally empty; don't expect transcripts there.
- Do NOT go looking in Zoom's folders for transcripts. `Documents\Zoom\`, `%APPDATA%\Zoom\data\` and `%LOCALAPPDATA%\Zoom\` hold only avatars/emoji/app cache; there is no local Zoom recording or Zoom-generated `.vtt`. Meeting audio is captured and transcribed by the apps above, never by Zoom's own transcript feature.

## Output shape (v1.2 core)
- Plaintext directly in the chat reply. Not a file, not an artifact, not a code block.
- Reply STARTS on the line `RISALAH RAPAT`. No opener, no closer.
- No markdown bold/italic/heading/table/bullet/emoji inside the risalah.
- Numbering as literal text: `I.`–`IV.` sections, `1.` `2.` items.
- One blank line between sections. No space/tab indentation.
- Placeholder `[...]`. Review notes go AFTER the risalah, one blank line down, headed `Catatan pengecekan (bukan bagian risalah):`, short numbered list. Omit when nothing to check.
- `.docx` ONLY if the user explicitly asks → then follow the `risalah-rapat-docx` skill (its layout spec = PRD 5.4).

## Skeleton
```
RISALAH RAPAT
NOMOR RR-<urut>/MS.1300/<tahun>

Hari, Tanggal : Kamis, 8 Oktober 2026
Waktu : 14:00 – 15:00 WIB
Tempat : Ruang Direktur Kelompok Keamanan Sistem Informasi Departemen Pengelolaan Sistem Informasi
Pemimpin Rapat : Kepala Departemen Pengelolaan Sistem Informasi
Agenda : <agenda persis dari user>

I. PEMBUKAAN
Rapat dipimpin oleh Bapak Adrianto selaku Manajer dari Kelompok Keamanan Siber Sistem Informasi (KKSI). Diskusi dihadiri oleh tim KKSI dan vendor pemelihara PT. <Nama Lengkap> (<Singkatan>).

II. TUJUAN PEMBAHASAN
Rapat ini bertujuan untuk membahas laporan mingguan dari tim vendor pemelihara dan telah sesuai dengan kontrak berjalan.

III. HASIL PEMBAHASAN
1. Terkait <topik>, <isi>.

IV. RENCANA TINDAK LANJUT
1. Agar ditindaklanjuti sesuai dengan hasil pembahasan.
```
II is the fixed sentence for vendor weekly reports; for any other meeting `Rapat ini bertujuan untuk ...` with the real purpose. IV is the fixed one-liner unless the user supplies specific follow-ups (who/what/when).

## Section III rules (what changed most in v1.2)
- ONE level only: `1.`, `2.`, ... No `a.`/`i.` sub-items. Detail lists (scores, names) inline, comma-joined with "yaitu".
- One topic = one number. NOT split by speaker side (vendor vs KKSI). Name the speaker only when meaning needs it (e.g. escalation to Palo Alto).
- Every item starts `Terkait <topik>,`.
- Order = order discussed in the meeting.
- 1–2 sentences, ~45 words max per item.
- Internal order: fact/status (number, value, condition) → cause ("dikarenakan"/"karena") → follow-up ("selanjutnya", "akan", "perlu dilakukan", "untuk dipastikan").
- KKSI directives fold into the item of their topic — never a separate block.
- Deadlines and PIC only if stated in the meeting. Deadline mentioned without a date → `[tenggat]` + report. Never write "dengan tenggat waktu" with no value.
- Semi-technical: name the system/component/account/rule/version/score/count. Do not explain basics (what a WAF or SQLi is). No raw detail (IPs, log fragments, commands) unless that IS the topic.
- Internal acronyms (KKSI, DPEA, DD, DLOG, CSIRT BSSN) used as-is, no expansion.
- Sentence patterns per PRD 6.2 (scores, findings, plans, checks, work counts) — read the PRD, don't invent variants.

## Sources & conflicts (PRD 6A)
| info | primary source |
|---|---|
| numbers, scores, counts, versions, release dates, product/PT names | PPT/PDF |
| explanation, context, vendor follow-up status | transcript |
| directives, requests, KKSI decisions | transcript |
| date, time, agenda, number, place | user's chat message |

Silent transcript cleanup allowed: obvious mishearings matchable to the deck, filler/repetition/unfinished fragments, generic "Speaker N" mapped to a party from context, mixed language normalised. Report via `[...]`: numbers conflicting with the deck, meaning not recoverable, person/PT/device names with no match anywhere, statements readable as opposites ("sudah" vs "belum"). Conflict → use the higher-priority source AND report it. Rule: a visible `[...]` beats a wrong number that looks tidy.

## Defaults (PRD 11)
- .docx not created unless asked.
- Tempat: Ruang Direktur Kelompok Keamanan Sistem Informasi Departemen Pengelolaan Sistem Informasi.
- Pemimpin Rapat (meta): Kepala Departemen Pengelolaan Sistem Informasi. Pembukaan paragraph: Bapak Adrianto, Manajer KKSI.
- Nomor: `RR-<urut>/MS.1300/<tahun>`; code `MS.1300` fixed; year = meeting year. Missing urut → `RR-/MS.1300/<tahun>` + report.
- No signature block. Satuan data `GB/hari`.
- Day name computed from the date; if it clashes with the day given, report (PRD's own example "Rabu, 8 Oktober 2026" was actually a Kamis).

## Pitfalls
- Do not inherit the 16 defects in PRD §8: typos (`crssedential`, `analisa`, `diangka`, `di detailkan`, `dibawah dari`), number year ≠ meeting year, leader differing between meta table and Pembukaan, `Kelompok Keamanan Sistem Informasi` vs `...Siber...`, vendor abbreviation without full PT, doubled `ke`/`akan`.
- English verbs with Indonesian affixes: pick ONE form per document — `di-whitelist`/`di-resolve` OR `sudah whitelist`/`sudah resolved`. Never mix.
- Anti-slop applies: formal, sopan, one idea per sentence, no filler, no opinion or conclusion from the writer. Only what was said in the meeting or shown on the deck.
- Report in chat ONLY: placeholders left, source conflicts for numbers, assumptions made. Never a summary of the document contents.
- Want a worked example? Two short reference outputs (vendor weekly, internal coordination) were produced from this PRD; regenerate rather than paste stale text.
